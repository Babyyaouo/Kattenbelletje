import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium smooth-transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "glass-button rounded-[14px] text-foreground hover:scale-105 active:scale-95 ios-shadow",
        destructive: "glass-button rounded-[14px] bg-destructive/20 text-destructive hover:bg-destructive/30 hover:scale-105 active:scale-95 ios-shadow",
        outline: "glass-button rounded-[14px] border border-border/30 hover:scale-105 active:scale-95 ios-shadow-sm",
        secondary: "glass-button rounded-[14px] bg-secondary/30 text-secondary-foreground hover:scale-105 active:scale-95 ios-shadow-sm",
        ghost: "rounded-[14px] hover:glass-card hover:scale-105 active:scale-95",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2 rounded-[14px]",
        sm: "h-9 px-3 rounded-[12px]",
        lg: "h-11 px-8 rounded-[18px]",
        icon: "h-10 w-10 rounded-[14px]",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
