import { ReactNode, useState, useEffect } from 'react';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface PhoneFrameProps {
  children: ReactNode;
  title?: string;
  showBack?: boolean;
  headerRight?: ReactNode;
  headerClassName?: string;
}

export const PhoneFrame = ({ children, title, showBack = false, headerRight, headerClassName }: PhoneFrameProps) => {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full h-screen overflow-hidden">
      <div className="absolute inset-0 gradient-bg" />
      <div className="relative h-full max-w-md mx-auto flex flex-col">
        {/* Status Bar - 毛玻璃效果 */}
        <div className="h-10 glass-card flex items-center justify-between px-8 text-xs font-medium border-b border-white/10 dark:border-white/5 ios-shadow-sm rounded-t-[24px]">
          <span className="text-foreground/70">{currentTime}</span>
          <div className="flex items-center gap-2 text-foreground/70">
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12.01 21.49L23.64 7c-.45-.34-4.93-4-11.64-4C5.28 3 .81 6.66.36 7l11.63 14.49.01.01.01-.01z"/>
            </svg>
            <svg className="w-3 h-3" viewBox="0 0 24 24" fill="currentColor">
              <rect x="2" y="6" width="20" height="12" rx="2" ry="2"/>
              <path d="M23 10v4l-3-2z"/>
            </svg>
          </div>
        </div>

        {/* Header - iOS 风格 */}
        {(title || showBack) && (
          <div className={headerClassName || "h-14 bg-background/70 backdrop-blur-md flex items-center justify-between px-4 border-b border-border/50 highlight-top"}>
            <div className="flex items-center gap-2 min-w-0 flex-1">
              {showBack && (
                <button
                  onClick={() => navigate(-1)}
                  className="p-2 glass-button rounded-[12px] smooth-transition hover:scale-105 active:scale-95"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              )}
              {title && <h1 className="text-lg font-semibold truncate">{title}</h1>}
            </div>
            {headerRight}
          </div>
        )}

        {/* Content - 自定义滚动条 */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {children}
        </div>

        {/* Home Indicator - iOS 风格 */}
        <div className="h-8 glass-card flex items-center justify-center border-t border-white/10 dark:border-white/5 ios-shadow-sm rounded-b-[24px]">
          <div className="w-32 h-1.5 bg-foreground/20 rounded-full" />
        </div>
      </div>
    </div>
  );
};
