import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { storage } from '@/lib/storage';
import { Character } from '@/types';
import { Edit, Trash2, User } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const CharacterDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [character, setCharacter] = useState<Character | null>(null);

  useEffect(() => {
    const chars = storage.getCharacters();
    const char = chars.find((c) => c.id === id);
    if (char) {
      setCharacter(char);
    } else {
      toast.error('角色档案不存在');
      navigate('/characters');
    }
  }, [id, navigate]);

  const handleDelete = () => {
    if (id) {
      storage.deleteCharacter(id);
      toast.success('角色档案已删除');
      navigate('/characters');
    }
  };

  if (!character) return null;

  return (
    <PhoneFrame
      title="角色档案详情"
      showBack
      headerRight={
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={() => navigate(`/characters/edit/${id}`)}>
            <Edit className="w-4 h-4" />
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="sm" variant="ghost">
                <Trash2 className="w-4 h-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>确认删除</AlertDialogTitle>
                <AlertDialogDescription>
                  确定要删除角色档案"{character.name}"吗？此操作无法撤销。
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>取消</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete}>删除</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      }
    >
      <div className="p-6 space-y-6 min-h-full bg-background/30 backdrop-blur-md">
        <div className="text-center">
          <h2 className="text-2xl font-bold">{character.name}</h2>
          <span className="inline-block text-sm px-3 py-1 rounded-full bg-primary/10 text-primary mt-2">
            角色档案
          </span>
        </div>

        <Tabs defaultValue="char" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="char">AI角色</TabsTrigger>
            <TabsTrigger value="user">用户身份</TabsTrigger>
          </TabsList>

          <TabsContent value="char" className="space-y-4 mt-6">
            <div className="flex flex-col items-center">
              <div className="w-32 h-32 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden mb-4">
                {character.char.avatar ? (
                  <img src={character.char.avatar} alt={character.char.name} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-16 h-16 text-primary" />
                )}
              </div>
              <h3 className="text-xl font-bold">{character.char.name}</h3>
            </div>

            {(character.char.profession || character.char.age) && (
              <Card className="p-4">
                <div className="grid grid-cols-2 gap-4">
                  {character.char.profession && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">职业</p>
                      <p className="font-medium">{character.char.profession}</p>
                    </div>
                  )}
                  {character.char.age && (
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">年龄</p>
                      <p className="font-medium">{character.char.age}岁</p>
                    </div>
                  )}
                </div>
              </Card>
            )}

            {character.char.personality && (
              <Card className="p-4">
                <h3 className="text-sm font-semibold mb-2 text-muted-foreground">性格描述</h3>
                <p className="text-foreground leading-relaxed">{character.char.personality}</p>
              </Card>
            )}

            <Card className="p-4">
              <h3 className="text-sm font-semibold mb-2 text-muted-foreground">角色设定</h3>
              <p className="text-foreground leading-relaxed whitespace-pre-wrap">{character.char.basicInfo}</p>
            </Card>
          </TabsContent>

          <TabsContent value="user" className="space-y-4 mt-6">
            <div className="flex flex-col items-center">
              <div className="w-32 h-32 rounded-full bg-accent/10 flex items-center justify-center overflow-hidden mb-4">
                {character.user.avatar ? (
                  <img src={character.user.avatar} alt={character.user.name} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-16 h-16 text-accent" />
                )}
              </div>
              <h3 className="text-xl font-bold">{character.user.name || '未设置'}</h3>
            </div>

            {character.user.basicInfo && (
              <>
                {(character.user.profession || character.user.age) && (
                  <Card className="p-4">
                    <div className="grid grid-cols-2 gap-4">
                      {character.user.profession && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">职业</p>
                          <p className="font-medium">{character.user.profession}</p>
                        </div>
                      )}
                      {character.user.age && (
                        <div>
                          <p className="text-sm text-muted-foreground mb-1">年龄</p>
                          <p className="font-medium">{character.user.age}岁</p>
                        </div>
                      )}
                    </div>
                  </Card>
                )}

                {character.user.personality && (
                  <Card className="p-4">
                    <h3 className="text-sm font-semibold mb-2 text-muted-foreground">性格描述</h3>
                    <p className="text-foreground leading-relaxed">{character.user.personality}</p>
                  </Card>
                )}

                <Card className="p-4">
                  <h3 className="text-sm font-semibold mb-2 text-muted-foreground">用户设定</h3>
                  <p className="text-foreground leading-relaxed whitespace-pre-wrap">{character.user.basicInfo}</p>
                </Card>
              </>
            )}

            {!character.user.basicInfo && (
              <Card className="p-4">
                <p className="text-muted-foreground text-center">未设置用户身份信息</p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </PhoneFrame>
  );
};

export default CharacterDetail;
