import { useState, useEffect } from 'react';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { storage } from '@/lib/storage';
import { ApiSettings } from '@/types';
import { toast } from 'sonner';
import { RefreshCw } from 'lucide-react';

const Settings = () => {
  const [settings, setSettings] = useState<ApiSettings>({
    apiKey: '',
    baseUrl: 'https://api.openai.com/v1',
    model: 'gpt-3.5-turbo',
  });
  const [models, setModels] = useState<string[]>(['gpt-3.5-turbo', 'gpt-4', 'gpt-4-turbo']);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const saved = storage.getApiSettings();
    if (saved) {
      setSettings(saved);
    }
  }, []);

  const handleSave = () => {
    if (!settings.apiKey) {
      toast.error('请输入API Key');
      return;
    }
    storage.setApiSettings(settings);
    toast.success('设置已保存');
  };

  const handleFetchModels = async () => {
    if (!settings.apiKey || !settings.baseUrl) {
      toast.error('请先填写API Key和Base URL');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${settings.baseUrl}/models`, {
        headers: {
          'Authorization': `Bearer ${settings.apiKey}`,
        },
      });

      if (!response.ok) throw new Error('获取模型列表失败');

      const data = await response.json();
      const modelIds = data.data.map((m: any) => m.id);
      setModels(modelIds);
      toast.success(`已获取 ${modelIds.length} 个模型`);
    } catch (error) {
      toast.error('获取模型失败，请检查API设置');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame title="启 - API设置" showBack>
      <div className="p-6 space-y-6 min-h-full bg-background/30 backdrop-blur-md">
        <div className="space-y-2">
          <Label htmlFor="apiKey">API Key</Label>
          <Input
            id="apiKey"
            type="password"
            placeholder="sk-..."
            value={settings.apiKey}
            onChange={(e) => setSettings({ ...settings, apiKey: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="baseUrl">Base URL</Label>
          <Input
            id="baseUrl"
            placeholder="https://api.openai.com/v1"
            value={settings.baseUrl}
            onChange={(e) => setSettings({ ...settings, baseUrl: e.target.value })}
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label>模型</Label>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleFetchModels}
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 mr-1 ${loading ? 'animate-spin' : ''}`} />
              拉取模型
            </Button>
          </div>
          <Select value={settings.model} onValueChange={(value) => setSettings({ ...settings, model: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {models.map((model) => (
                <SelectItem key={model} value={model}>
                  {model}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button onClick={handleSave} className="w-full">
          保存设置
        </Button>
      </div>
    </PhoneFrame>
  );
};

export default Settings;
