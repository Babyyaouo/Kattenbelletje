import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus, MessageSquare, User } from 'lucide-react';
import { storage } from '@/lib/storage';
import { ChatSession, Character } from '@/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const ChatList = () => {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [showDialog, setShowDialog] = useState(false);

  useEffect(() => {
    setSessions(storage.getChatSessions());
    setCharacters(storage.getCharacters());
  }, []);

  const createChat = (characterId: string) => {
    const character = characters.find(c => c.id === characterId);
    if (!character) return;

    const newSession: ChatSession = {
      id: Date.now().toString(),
      characterId,
      messages: [],
      createdAt: Date.now(),
    };

    storage.addChatSession(newSession);
    toast.success(`已创建与${character.char.name}的聊天`);
    setShowDialog(false);
    navigate(`/chat/${newSession.id}`);
  };

  const getCharacter = (characterId: string) => {
    return storage.getCharacters().find(c => c.id === characterId);
  };

  const getLastMessage = (session: ChatSession) => {
    if (session.messages.length === 0) return '暂无消息';
    const last = session.messages[session.messages.length - 1];
    return last.content;
  };

  return (
    <PhoneFrame
      title="𝒩ℯ𝓍𝓊𝓈"
      showBack
      headerRight={
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-1" />
              新建
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>选择角色档案</DialogTitle>
            </DialogHeader>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {characters.length === 0 ? (
                <p className="text-center text-muted-foreground py-4">
                  还没有角色档案，请先在"序"中创建
                </p>
              ) : (
                characters.map((char) => (
                  <Card
                    key={char.id}
                    className="p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => createChat(char.id)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                        {char.char.avatar ? (
                          <img src={char.char.avatar} alt={char.char.name} className="w-full h-full object-cover" />
                        ) : (
                          <User className="w-6 h-6 text-primary" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium">{char.name}</h3>
                        {char.char.personality && (
                          <p className="text-sm text-muted-foreground line-clamp-1">
                            {char.char.personality}
                          </p>
                        )}
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </DialogContent>
        </Dialog>
      }
    >
      <div className="p-4 space-y-2 min-h-full bg-background/30 backdrop-blur-md">
        {sessions.length === 0 ? (
          <div className="text-center py-12">
            <MessageSquare className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
            <p className="text-muted-foreground mb-4">还没有聊天记录</p>
            <Button onClick={() => setShowDialog(true)}>
              创建第一个聊天
            </Button>
          </div>
        ) : (
          sessions.map((session) => {
            const character = getCharacter(session.characterId);
            if (!character) return null;

            return (
              <Card
                key={session.id}
                className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => navigate(`/chat/${session.id}`)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                    {character.char.avatar ? (
                      <img src={character.char.avatar} alt={character.char.name} className="w-full h-full object-cover" />
                    ) : (
                      <User className="w-6 h-6 text-primary" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-medium mb-1">{character.char.name}</h3>
                    <p className="text-sm text-muted-foreground truncate">
                      {getLastMessage(session)}
                    </p>
                  </div>
                </div>
              </Card>
            );
          })
        )}
      </div>
    </PhoneFrame>
  );
};

export default ChatList;
