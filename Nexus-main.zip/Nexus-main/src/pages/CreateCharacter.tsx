import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { storage } from '@/lib/storage';
import { Character, RoleInfo } from '@/types';
import { toast } from 'sonner';
import { Upload, Loader2 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const CreateCharacter = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEditing = !!id;
  const [loading, setLoading] = useState(false);
  const [charForm, setCharForm] = useState<RoleInfo>({
    name: '',
    avatar: '',
    basicInfo: '',
  });
  const [userForm, setUserForm] = useState<RoleInfo>({
    name: '',
    avatar: '',
    basicInfo: '',
  });
  const [charAvatarUrl, setCharAvatarUrl] = useState('');
  const [userAvatarUrl, setUserAvatarUrl] = useState('');

  useEffect(() => {
    if (isEditing) {
      const characters = storage.getCharacters();
      const existingChar = characters.find(c => c.id === id);
      if (existingChar) {
        setCharForm(existingChar.char);
        setUserForm(existingChar.user);
      } else {
        toast.error('角色不存在');
        navigate('/characters');
      }
    }
  }, [id, isEditing, navigate]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'char' | 'user') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'char') {
          setCharForm({ ...charForm, avatar: reader.result as string });
        } else {
          setUserForm({ ...userForm, avatar: reader.result as string });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const applyAvatarUrl = (type: 'char' | 'user') => {
    const url = type === 'char' ? charAvatarUrl : userAvatarUrl;
    if (!url.trim()) {
      toast.error('请输入头像URL');
      return;
    }
    if (type === 'char') {
      setCharForm({ ...charForm, avatar: url });
      setCharAvatarUrl('');
    } else {
      setUserForm({ ...userForm, avatar: url });
      setUserAvatarUrl('');
    }
    toast.success('头像URL已设置');
  };

  const generateProfile = async () => {
    if (!charForm.name || !charForm.basicInfo) {
      toast.error('请至少填写角色名称和角色设定');
      return;
    }

    setLoading(true);
    try {
      const apiSettings = storage.getApiSettings();
      if (!apiSettings?.apiKey) {
        toast.error('请先在"启"中配置API');
        navigate('/settings');
        return;
      }

      let updatedChar = charForm;

      // 如果是编辑模式且已有职业/年龄/性格，直接使用；否则才生成
      if (!isEditing || !charForm.profession) {
        // 生成角色摘要（聚焦于char角色）
        const response = await fetch(`${apiSettings.baseUrl}/chat/completions`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiSettings.apiKey}`,
          },
          body: JSON.stringify({
            model: apiSettings.model,
            messages: [
              {
                role: 'system',
                content: '你是一个角色分析助手。请从给定的角色设定中提取：职业、年龄、性格描述（50字以内）。以JSON格式返回：{"profession":"职业","age":"年龄","personality":"性格描述"}',
              },
              {
                role: 'user',
                content: charForm.basicInfo,
              },
            ],
            temperature: 0.7,
          }),
        });

        if (!response.ok) throw new Error('生成失败');

        const data = await response.json();
        let content = data.choices[0].message.content;
        
        // 清理markdown代码块标记
        content = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
        
        const summary = JSON.parse(content);
        updatedChar = {
          ...charForm,
          profession: summary.profession,
          age: summary.age,
          personality: summary.personality,
        };
      }

      if (isEditing) {
        // 编辑模式：更新现有角色
        storage.updateCharacter(id!, {
          name: charForm.name,
          char: updatedChar,
          user: userForm,
        });
        toast.success('角色档案已更新');
      } else {
        // 创建模式：添加新角色
        const character: Character = {
          id: Date.now().toString(),
          name: charForm.name,
          type: 'profile',
          char: updatedChar,
          user: userForm,
        };
        storage.addCharacter(character);
        toast.success('角色档案创建成功');
      }
      
      navigate('/characters');
    } catch (error) {
      console.error('Failed to save character:', error);
      if (error instanceof Error) {
        toast.error(error.message);
      } else {
        toast.error('操作失败');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <PhoneFrame title={isEditing ? "编辑角色档案" : "创建角色档案"} showBack>
      <div className="p-6 space-y-6 min-h-full bg-background/30 backdrop-blur-md">
        <Tabs defaultValue="char" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="char">AI角色 (Char)</TabsTrigger>
            <TabsTrigger value="user">我的身份 (User)</TabsTrigger>
          </TabsList>

          <TabsContent value="char" className="space-y-6 mt-6">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                  {charForm.avatar ? (
                    <img src={charForm.avatar} alt="char avatar" className="w-full h-full object-cover" />
                  ) : (
                    <Upload className="w-8 h-8 text-muted-foreground" />
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, 'char')}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
              
              <div className="w-full space-y-2">
                <Label className="text-sm">输入头像URL（推荐）</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://example.com/avatar.jpg"
                    value={charAvatarUrl}
                    onChange={(e) => setCharAvatarUrl(e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    onClick={() => applyAvatarUrl('char')}
                    size="sm"
                  >
                    应用
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  💡 或点击上方圆圈上传本地图片
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="charName">角色名称</Label>
              <Input
                id="charName"
                placeholder="AI要扮演的角色名称"
                value={charForm.name}
                onChange={(e) => setCharForm({ ...charForm, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="charBasicInfo">角色设定</Label>
              <Textarea
                id="charBasicInfo"
                placeholder="详细描述AI角色的背景、性格、特点等..."
                value={charForm.basicInfo}
                onChange={(e) => setCharForm({ ...charForm, basicInfo: e.target.value })}
                rows={8}
              />
            </div>
          </TabsContent>

          <TabsContent value="user" className="space-y-6 mt-6">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center overflow-hidden">
                  {userForm.avatar ? (
                    <img src={userForm.avatar} alt="user avatar" className="w-full h-full object-cover" />
                  ) : (
                    <Upload className="w-8 h-8 text-muted-foreground" />
                  )}
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleImageUpload(e, 'user')}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>
              
              <div className="w-full space-y-2">
                <Label className="text-sm">输入头像URL（推荐）</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="https://example.com/avatar.jpg"
                    value={userAvatarUrl}
                    onChange={(e) => setUserAvatarUrl(e.target.value)}
                    className="flex-1"
                  />
                  <Button
                    onClick={() => applyAvatarUrl('user')}
                    size="sm"
                  >
                    应用
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  💡 或点击上方圆圈上传本地图片
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="userName">用户名称</Label>
              <Input
                id="userName"
                placeholder="你的角色名称"
                value={userForm.name}
                onChange={(e) => setUserForm({ ...userForm, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="userBasicInfo">用户设定</Label>
              <Textarea
                id="userBasicInfo"
                placeholder="描述你的角色背景、性格等（可选）..."
                value={userForm.basicInfo}
                onChange={(e) => setUserForm({ ...userForm, basicInfo: e.target.value })}
                rows={8}
              />
            </div>
          </TabsContent>
        </Tabs>

        <Button
          onClick={generateProfile}
          disabled={!charForm.name || !charForm.basicInfo || loading}
          className="w-full"
        >
          {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {isEditing ? "保存修改" : "生成角色档案"}
        </Button>
      </div>
    </PhoneFrame>
  );
};

export default CreateCharacter;
