import { useNavigate } from 'react-router-dom';
import { Settings, Users, MessageSquare, BookOpen, Moon, Sun, Sparkles, Image as ImageIcon, Music, Cloud } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

const defaultApps = [
  { id: 'settings', name: '启', icon: Settings, route: '/settings', color: 'from-blue-400/30 to-blue-600/30', page: 0 },
  { id: 'characters', name: '序', icon: Users, route: '/characters', color: 'from-purple-400/30 to-purple-600/30', page: 0 },
  { id: 'chat', name: '𝒩ℯ𝓍𝓊𝓈', icon: MessageSquare, route: '/chat', color: 'from-green-400/30 to-green-600/30', page: 1 },
  { id: 'worldbooks', name: '世界书', icon: BookOpen, route: '/worldbooks', color: 'from-orange-400/30 to-orange-600/30', page: 1 },
  { id: 'memories', name: 'Vestige', icon: Sparkles, route: '/memories', color: 'from-pink-400/30 to-pink-600/30', page: 2 },
  { id: 'gallery', name: '画廊', icon: ImageIcon, route: '/gallery', color: 'from-cyan-400/30 to-cyan-600/30', page: 2 },
];

const Home = () => {
  const navigate = useNavigate();
  const [isDark, setIsDark] = useState(false);
  const [wallpaper, setWallpaper] = useState<string>('');
  const [customIcons, setCustomIcons] = useState<Record<string, string>>({});
  const [currentPage, setCurrentPage] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [widgetBg, setWidgetBg] = useState<string>('');
  const [musicData, setMusicData] = useState({ title: '暂无播放', artist: '' });
  const [weatherData, setWeatherData] = useState({ location: '未设置', temp: '22', condition: '晴' });

  useEffect(() => {
    const root = window.document.documentElement;
    const isDarkMode = root.classList.contains('dark');
    setIsDark(isDarkMode);
    
    // 加载壁纸
    const loadWallpaper = () => {
      const savedWallpaper = localStorage.getItem('home_wallpaper');
      if (savedWallpaper) {
        setWallpaper(savedWallpaper);
      }
    };
    loadWallpaper();
    
    // 监听storage变化
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'home_wallpaper') {
        setWallpaper(e.newValue || '');
      }
    };
    window.addEventListener('storage', handleStorageChange);
    
    // 监听自定义事件（同一标签页内的更新）
    const handleWallpaperUpdate = () => {
      loadWallpaper();
    };
    window.addEventListener('wallpaper-updated', handleWallpaperUpdate);
    
    // 加载小组件背景
    const savedWidgetBg = localStorage.getItem('widget_bg');
    if (savedWidgetBg) {
      setWidgetBg(savedWidgetBg);
    }
    
    // 加载自定义图标
    const savedIcons = localStorage.getItem('custom_icons');
    if (savedIcons) {
      try {
        setCustomIcons(JSON.parse(savedIcons));
      } catch (e) {
        console.error('Failed to parse custom icons:', e);
      }
    }

    // 加载音乐数据
    const savedMusic = localStorage.getItem('widget_music');
    if (savedMusic) {
      try {
        setMusicData(JSON.parse(savedMusic));
      } catch (e) {
        console.error('Failed to parse music data:', e);
      }
    }

    // 加载天气数据
    const savedWeather = localStorage.getItem('widget_weather');
    if (savedWeather) {
      try {
        setWeatherData(JSON.parse(savedWeather));
      } catch (e) {
        console.error('Failed to parse weather data:', e);
      }
    }

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('wallpaper-updated', handleWallpaperUpdate);
    };
  }, []);

  const toggleTheme = () => {
    const root = window.document.documentElement;
    const newIsDark = !isDark;
    setIsDark(newIsDark);
    if (newIsDark) {
      root.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX);
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStart) return;
    const touchEnd = e.changedTouches[0].clientX;
    const diff = touchStart - touchEnd;
    
    if (Math.abs(diff) > 50) {
      if (diff > 0 && currentPage < 2) {
        setCurrentPage(currentPage + 1);
      } else if (diff < 0 && currentPage > 0) {
        setCurrentPage(currentPage - 1);
      }
    }
    setTouchStart(null);
  };

  const handleWidgetBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) {
        toast.error('图片太大，请选择小于500KB的图片');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageData = reader.result as string;
        setWidgetBg(imageData);
        localStorage.setItem('widget_bg', imageData);
        toast.success('小组件背景已设置');
      };
      reader.readAsDataURL(file);
    }
  };

  const currentApps = defaultApps.filter(app => app.page === currentPage);

  return (
    <div 
      className="relative w-full h-screen overflow-hidden"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* 背景壁纸 */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-500"
        style={wallpaper ? { backgroundImage: `url(${wallpaper})` } : {}}
      />
      {!wallpaper && (
        <div className="absolute inset-0 glass transition-colors duration-300" />
      )}
      
      <div className="relative h-full max-w-md mx-auto flex flex-col px-6 pt-16 pb-8">
        {/* 状态栏区域 */}
        <div className="flex justify-between items-center mb-8 text-sm font-semibold glass-card px-5 py-3 ios-shadow">
          <input 
            type="text" 
            placeholder="点击编辑签名"
            defaultValue={localStorage.getItem('user_signature') || ''}
            onBlur={(e) => {
              localStorage.setItem('user_signature', e.target.value);
              toast.success('个性签名已保存');
            }}
            className="bg-transparent border-none outline-none text-foreground/90 placeholder:text-foreground/50 w-32"
          />
          <Button
            size="sm"
            variant="ghost"
            onClick={toggleTheme}
            className="h-9 w-9 p-0 rounded-[12px] glass-button"
          >
            {isDark ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
          </Button>
        </div>

        {/* 时间日期 */}
        <div className="text-center mb-8 glass-card p-8 rounded-[32px] ios-shadow-lg">
          <h1 className="text-7xl font-light mb-2 text-foreground/95">
            {new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', hour12: false })}
          </h1>
          <p className="text-lg font-semibold text-foreground/75">
            {new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' })}
          </p>
        </div>

        {/* 小组件区域 */}
        {currentPage === 0 && (
          <div className="mb-8 px-4 space-y-4">
            <label 
              className="glass-card p-6 rounded-[28px] ios-shadow-lg bg-cover bg-center cursor-pointer hover:scale-[1.02] smooth-transition active:scale-95 block"
              style={widgetBg ? { backgroundImage: `url(${widgetBg})` } : {}}
            >
              <input
                type="file"
                accept="image/*"
                onChange={handleWidgetBgUpload}
                className="hidden"
              />
              <div className={`flex items-center gap-4 ${widgetBg ? 'backdrop-blur-sm bg-black/20 p-3 rounded-[16px]' : ''}`}>
                <div className="w-12 h-12 rounded-[16px] glass-card bg-gradient-to-br from-purple-400/30 to-purple-600/30 flex items-center justify-center">
                  <ImageIcon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground/90">添加图片</h3>
                  <p className="text-sm text-foreground/60">点击选择图片</p>
                </div>
              </div>
            </label>
            
            <div className="grid grid-cols-2 gap-4">
              <label 
                className="glass-card p-4 rounded-[24px] ios-shadow cursor-pointer hover:scale-[1.02] smooth-transition active:scale-95 bg-cover bg-center relative"
                style={localStorage.getItem('widget_music_bg') ? { backgroundImage: `url(${localStorage.getItem('widget_music_bg')})` } : {}}
              >
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      if (file.size > 500000) {
                        toast.error('图片太大，请选择小于500KB的图片');
                        return;
                      }
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        const imageData = reader.result as string;
                        localStorage.setItem('widget_music_bg', imageData);
                        toast.success('音乐小组件背景已设置');
                        window.location.reload();
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                <div className={localStorage.getItem('widget_music_bg') ? 'backdrop-blur-sm bg-black/20 p-2 rounded-[12px]' : ''}>
                  <Music className="w-8 h-8 text-foreground/70 mb-2" />
                  <p className="text-sm font-medium text-foreground/90">正在播放</p>
                  <input 
                    type="text"
                    placeholder="歌曲名"
                    value={musicData.title}
                    onChange={(e) => {
                      e.stopPropagation();
                      const newData = { ...musicData, title: e.target.value };
                      setMusicData(newData);
                      localStorage.setItem('widget_music', JSON.stringify(newData));
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="text-xs text-foreground/60 truncate bg-transparent border-none outline-none w-full mt-1 relative z-10"
                  />
                  <input 
                    type="text"
                    placeholder="艺术家"
                    value={musicData.artist}
                    onChange={(e) => {
                      e.stopPropagation();
                      const newData = { ...musicData, artist: e.target.value };
                      setMusicData(newData);
                      localStorage.setItem('widget_music', JSON.stringify(newData));
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="text-xs text-foreground/50 truncate bg-transparent border-none outline-none w-full relative z-10"
                  />
                </div>
              </label>
              <label 
                className="glass-card p-4 rounded-[24px] ios-shadow cursor-pointer hover:scale-[1.02] smooth-transition active:scale-95 bg-cover bg-center relative"
                style={localStorage.getItem('widget_weather_bg') ? { backgroundImage: `url(${localStorage.getItem('widget_weather_bg')})` } : {}}
              >
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      if (file.size > 500000) {
                        toast.error('图片太大，请选择小于500KB的图片');
                        return;
                      }
                      const reader = new FileReader();
                      reader.onloadend = () => {
                        const imageData = reader.result as string;
                        localStorage.setItem('widget_weather_bg', imageData);
                        toast.success('天气小组件背景已设置');
                        window.location.reload();
                      };
                      reader.readAsDataURL(file);
                    }
                  }}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                <div className={localStorage.getItem('widget_weather_bg') ? 'backdrop-blur-sm bg-black/20 p-2 rounded-[12px]' : ''}>
                  <Cloud className="w-8 h-8 text-foreground/70 mb-2" />
                  <p className="text-sm font-medium text-foreground/90">天气</p>
                  <div className="flex items-center gap-1 mt-1">
                    <input 
                      type="text"
                      placeholder="22"
                      value={weatherData.temp}
                      onChange={(e) => {
                        e.stopPropagation();
                        const newData = { ...weatherData, temp: e.target.value };
                        setWeatherData(newData);
                        localStorage.setItem('widget_weather', JSON.stringify(newData));
                      }}
                      onClick={(e) => e.stopPropagation()}
                      className="text-xs text-foreground/60 bg-transparent border-none outline-none w-8 relative z-10"
                    />
                    <span className="text-xs text-foreground/60">°C</span>
                    <input 
                      type="text"
                      placeholder="晴"
                      value={weatherData.condition}
                      onChange={(e) => {
                        e.stopPropagation();
                        const newData = { ...weatherData, condition: e.target.value };
                        setWeatherData(newData);
                        localStorage.setItem('widget_weather', JSON.stringify(newData));
                      }}
                      onClick={(e) => e.stopPropagation()}
                      className="text-xs text-foreground/60 bg-transparent border-none outline-none flex-1 relative z-10"
                    />
                  </div>
                  <input 
                    type="text"
                    placeholder="地点"
                    value={weatherData.location}
                    onChange={(e) => {
                      e.stopPropagation();
                      const newData = { ...weatherData, location: e.target.value };
                      setWeatherData(newData);
                      localStorage.setItem('widget_weather', JSON.stringify(newData));
                    }}
                    onClick={(e) => e.stopPropagation()}
                    className="text-xs text-foreground/50 bg-transparent border-none outline-none w-full relative z-10"
                  />
                </div>
              </label>
            </div>
          </div>
        )}

        {/* 应用图标网格 */}
        <div className="flex-1 grid grid-cols-4 gap-x-6 gap-y-10 content-start px-4">
          {currentApps.map((app) => (
            <button
              key={app.id}
              onClick={() => navigate(app.route)}
              className="flex flex-col items-center gap-2.5 group active:scale-95 smooth-transition fade-in hover:-translate-y-1"
            >
              {/* 图标容器 */}
              <div className={`
                relative w-16 h-16 rounded-[20px] overflow-hidden
                ${customIcons[app.id] ? 'glass-card' : `glass-card bg-gradient-to-br ${app.color}`}
                ios-shadow
                group-hover:ios-shadow-lg
                group-hover:scale-110
                group-active:scale-95
                smooth-transition
                highlight-top
              `}>
                {customIcons[app.id] ? (
                  <img 
                    src={customIcons[app.id]} 
                    alt={app.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <app.icon className="w-8 h-8 text-white drop-shadow-2xl" strokeWidth={2.5} />
                  </div>
                )}
              </div>
              
              {/* 应用名称 */}
              <span className="text-xs font-semibold drop-shadow-md max-w-full truncate px-1 text-foreground/95">
                {app.name}
              </span>
            </button>
          ))}
        </div>

        {/* 页面指示器 */}
        <div className="flex justify-center gap-2 mt-auto pt-6 pb-2">
          {[0, 1, 2].map((page) => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`h-2 rounded-full smooth-transition ${
                page === currentPage 
                  ? 'w-8 bg-foreground/60' 
                  : 'w-2 bg-foreground/20'
              }`}
            />
          ))}
        </div>
        
        {/* 底部指示器 */}
        <div className="flex justify-center pt-2 pb-4">
          <div className="w-32 h-1.5 glass-card rounded-full backdrop-blur-xl ios-shadow-sm" />
        </div>
      </div>
    </div>
  );
};

export default Home;
