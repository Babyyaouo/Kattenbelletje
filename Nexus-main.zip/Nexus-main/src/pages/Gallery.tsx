import { useState, useRef, useEffect } from 'react';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Image as ImageIcon, Upload, Sparkles, Home as HomeIcon, Code, Calendar } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';

const Gallery = () => {
  const [wallpaper, setWallpaper] = useState<string>('');
  const [bubbleCode, setBubbleCode] = useState('');
  const [customIcons, setCustomIcons] = useState<Record<string, string>>({});
  const [selectedFont, setSelectedFont] = useState<string>('');
  const [bubblePreview, setBubblePreview] = useState<string>('');
  const [widgetBg, setWidgetBg] = useState<string>('');
  const wallpaperInputRef = useRef<HTMLInputElement>(null);
  const iconInputRef = useRef<HTMLInputElement>(null);
  const fontInputRef = useRef<HTMLInputElement>(null);
  const widgetBgInputRef = useRef<HTMLInputElement>(null);
  const [selectedIconApp, setSelectedIconApp] = useState<string>('');
  
  // URL input states
  const [wallpaperUrl, setWallpaperUrl] = useState<string>('');
  const [widgetBgUrl, setWidgetBgUrl] = useState<string>('');
  const [iconUrl, setIconUrl] = useState<string>('');

  const apps = [
    { id: 'settings', name: '启' },
    { id: 'characters', name: '角色' },
    { id: 'chat', name: '对话' },
    { id: 'worldbooks', name: '世界书' },
    { id: 'memories', name: '记忆碎片' },
    { id: 'gallery', name: '画廊' },
  ];

  const handleWallpaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) { // 500KB limit
        toast.error('图片太大，请选择小于500KB的图片');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageData = reader.result as string;
        setWallpaper(imageData);
        try {
          localStorage.setItem('home_wallpaper', imageData);
          window.dispatchEvent(new Event('wallpaper-updated'));
          toast.success('壁纸已设置');
        } catch (e) {
          toast.error('存储空间不足，请使用更小的图片或清理数据');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleWidgetBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 300000) { // 300KB limit
        toast.error('图片太大，请选择小于300KB的图片');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageData = reader.result as string;
        setWidgetBg(imageData);
        try {
          localStorage.setItem('widget_bg', imageData);
          toast.success('小组件背景已设置');
        } catch (e) {
          toast.error('存储空间不足，请使用更小的图片');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selectedIconApp) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageData = reader.result as string;
        const updated = { ...customIcons, [selectedIconApp]: imageData };
        setCustomIcons(updated);
        localStorage.setItem('custom_icons', JSON.stringify(updated));
        toast.success(`${apps.find(a => a.id === selectedIconApp)?.name} 图标已更新`);
        setSelectedIconApp('');
      };
      reader.readAsDataURL(file);
    }
  };

  useEffect(() => {
    // 加载自定义字体
    const savedFontName = localStorage.getItem('custom_font_name');
    const savedFontData = localStorage.getItem('custom_font_data');
    if (savedFontName && savedFontData) {
      setSelectedFont(savedFontName);
      const style = document.createElement('style');
      style.id = 'custom-font-face';
      style.textContent = `
        @font-face {
          font-family: 'CustomFont';
          src: url('${savedFontData}');
        }
      `;
      document.head.appendChild(style);
      document.documentElement.style.fontFamily = 'CustomFont, -apple-system, BlinkMacSystemFont, sans-serif';
    }

    const savedBubbleCode = localStorage.getItem('bubble_code');
    if (savedBubbleCode) {
      setBubbleCode(savedBubbleCode);
      setBubblePreview(savedBubbleCode);
    }

    const savedIcons = localStorage.getItem('custom_icons');
    if (savedIcons) {
      setCustomIcons(JSON.parse(savedIcons));
    }

    const savedWallpaper = localStorage.getItem('home_wallpaper');
    if (savedWallpaper) {
      setWallpaper(savedWallpaper);
    }

    const savedWidgetBg = localStorage.getItem('widget_bg');
    if (savedWidgetBg) {
      setWidgetBg(savedWidgetBg);
    }
  }, []);

  const handleFontUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && (file.name.endsWith('.ttf') || file.name.endsWith('.otf') || file.name.endsWith('.woff') || file.name.endsWith('.woff2'))) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const fontData = reader.result as string;
        const fontName = file.name.split('.')[0];
        
        // 移除旧的字体样式
        const oldStyle = document.getElementById('custom-font-face');
        if (oldStyle) oldStyle.remove();
        
        // 创建新的字体样式
        const style = document.createElement('style');
        style.id = 'custom-font-face';
        style.textContent = `
          @font-face {
            font-family: 'CustomFont';
            src: url('${fontData}');
          }
        `;
        document.head.appendChild(style);
        
        // 应用字体
        document.documentElement.style.fontFamily = 'CustomFont, -apple-system, BlinkMacSystemFont, sans-serif';
        
        // 保存
        localStorage.setItem('custom_font_name', fontName);
        localStorage.setItem('custom_font_data', fontData);
        setSelectedFont(fontName);
        toast.success('字体已上传并应用');
      };
      reader.readAsDataURL(file);
    } else {
      toast.error('请上传有效的字体文件（.ttf, .otf, .woff, .woff2）');
    }
  };

  const saveBubbleCode = () => {
    if (!bubbleCode.trim()) {
      toast.error('请输入气泡代码');
      return;
    }
    
    try {
      localStorage.setItem('bubble_code', bubbleCode);
      setBubblePreview(bubbleCode);
      
      // Apply immediately by injecting style
      const existingStyle = document.getElementById('custom-bubble-style');
      if (existingStyle) {
        existingStyle.remove();
      }
      
      const styleEl = document.createElement('style');
      styleEl.id = 'custom-bubble-style';
      styleEl.textContent = bubbleCode;
      document.head.appendChild(styleEl);
      
      toast.success('气泡样式已应用');
    } catch (e) {
      console.error('Failed to save bubble code:', e);
      toast.error('保存失败');
    }
  };

  const clearFont = () => {
    localStorage.removeItem('custom_font_name');
    localStorage.removeItem('custom_font_data');
    setSelectedFont('');
    const oldStyle = document.getElementById('custom-font-face');
    if (oldStyle) oldStyle.remove();
    document.documentElement.style.fontFamily = '-apple-system, BlinkMacSystemFont, sans-serif';
    toast.success('已恢复系统默认字体');
  };

  const clearWallpaper = () => {
    setWallpaper('');
    localStorage.removeItem('home_wallpaper');
    window.dispatchEvent(new Event('wallpaper-updated'));
    toast.success('壁纸已清除');
  };

  const clearWidgetBg = () => {
    setWidgetBg('');
    localStorage.removeItem('widget_bg');
    toast.success('小组件背景已清除');
  };

  const resetIcon = (appId: string) => {
    const updated = { ...customIcons };
    delete updated[appId];
    setCustomIcons(updated);
    localStorage.setItem('custom_icons', JSON.stringify(updated));
    toast.success('图标已重置');
  };

  const applyWallpaperUrl = () => {
    if (!wallpaperUrl.trim()) {
      toast.error('请输入图片URL');
      return;
    }
    setWallpaper(wallpaperUrl);
    localStorage.setItem('home_wallpaper', wallpaperUrl);
    window.dispatchEvent(new Event('wallpaper-updated'));
    toast.success('壁纸URL已设置');
    setWallpaperUrl('');
  };

  const applyWidgetBgUrl = () => {
    if (!widgetBgUrl.trim()) {
      toast.error('请输入图片URL');
      return;
    }
    setWidgetBg(widgetBgUrl);
    localStorage.setItem('widget_bg', widgetBgUrl);
    toast.success('小组件背景URL已设置');
    setWidgetBgUrl('');
  };

  const applyIconUrl = () => {
    if (!iconUrl.trim() || !selectedIconApp) {
      toast.error('请输入图片URL');
      return;
    }
    const updated = { ...customIcons, [selectedIconApp]: iconUrl };
    setCustomIcons(updated);
    localStorage.setItem('custom_icons', JSON.stringify(updated));
    toast.success(`${apps.find(a => a.id === selectedIconApp)?.name} 图标URL已设置`);
    setIconUrl('');
    setSelectedIconApp('');
  };

  return (
    <PhoneFrame title="画廊" showBack>
      <div className="p-6 space-y-6 custom-scrollbar overflow-y-auto max-h-[calc(100vh-120px)] min-h-full bg-background/30 backdrop-blur-md">
        <Tabs defaultValue="wallpaper" className="w-full">
          <TabsList className="grid w-full grid-cols-4 glass-card p-1.5 gap-1 text-xs">
            <TabsTrigger value="wallpaper" className="rounded-[12px] data-[state=active]:glass-button data-[state=active]:glow">
              <HomeIcon className="w-3.5 h-3.5" />
            </TabsTrigger>
            <TabsTrigger value="icons" className="rounded-[12px] data-[state=active]:glass-button data-[state=active]:glow">
              <ImageIcon className="w-3.5 h-3.5" />
            </TabsTrigger>
            <TabsTrigger value="bubble" className="rounded-[12px] data-[state=active]:glass-button data-[state=active]:glow">
              <Code className="w-3.5 h-3.5" />
            </TabsTrigger>
            <TabsTrigger value="font" className="rounded-[12px] data-[state=active]:glass-button data-[state=active]:glow">
              <Sparkles className="w-3.5 h-3.5" />
            </TabsTrigger>
          </TabsList>

          <TabsContent value="wallpaper" className="space-y-6 mt-6 fade-in">
            <div className="glass-card p-6 space-y-4 scale-in">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">主页壁纸</h3>
              </div>

              {wallpaper && (
                <div className="relative rounded-[20px] overflow-hidden ios-shadow">
                  <img 
                    src={wallpaper} 
                    alt="壁纸预览" 
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute inset-0 glass flex items-center justify-center opacity-0 hover:opacity-100 smooth-transition">
                    <Button
                      variant="destructive"
                      onClick={clearWallpaper}
                      className="rounded-[14px] glass-button"
                    >
                      清除壁纸
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="glass-card p-4 rounded-[16px] space-y-3">
                  <Label className="text-sm font-semibold">方式1：输入图片URL（推荐）</Label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="https://example.com/image.jpg"
                      value={wallpaperUrl}
                      onChange={(e) => setWallpaperUrl(e.target.value)}
                      className="flex-1 rounded-[12px]"
                    />
                    <Button
                      onClick={applyWallpaperUrl}
                      className="glass-button rounded-[12px]"
                    >
                      应用
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    💡 使用图片URL不占用本地存储空间
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>方式2：上传本地图片</Label>
                  <input
                    ref={wallpaperInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleWallpaperUpload}
                    className="hidden"
                  />
                  <Button
                    onClick={() => wallpaperInputRef.current?.click()}
                    className="w-full glass-button"
                    variant="outline"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    选择图片
                  </Button>
                  <p className="text-xs text-destructive">
                    ⚠️ 建议图片小于500KB以节省空间
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="icons" className="space-y-6 mt-6 fade-in">
            <div className="glass-card p-6 space-y-4 scale-in">
              <div className="flex items-center gap-2 mb-4">
                <ImageIcon className="w-5 h-5 text-primary" />
                <h3 className="text-lg font-semibold">自定义图标</h3>
              </div>

              <div className="space-y-4">
                {apps.map((app) => (
                  <div
                    key={app.id}
                    className="glass-card p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {customIcons[app.id] ? (
                          <img
                            src={customIcons[app.id]}
                            alt={app.name}
                            className="w-12 h-12 rounded-[14px] object-cover ios-shadow"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-[14px] glass-card flex items-center justify-center">
                            <ImageIcon className="w-6 h-6 text-muted-foreground" />
                          </div>
                        )}
                        <span className="font-medium">{app.name}</span>
                      </div>

                      <div className="flex gap-2">
                        {customIcons[app.id] && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => resetIcon(app.id)}
                            className="rounded-[12px]"
                          >
                            重置
                          </Button>
                        )}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Input
                        placeholder="输入图片URL"
                        value={selectedIconApp === app.id ? iconUrl : ''}
                        onChange={(e) => {
                          setSelectedIconApp(app.id);
                          setIconUrl(e.target.value);
                        }}
                        className="flex-1 rounded-[12px] text-sm"
                      />
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedIconApp(app.id);
                          applyIconUrl();
                        }}
                        className="rounded-[12px] glass-button"
                      >
                        应用
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedIconApp(app.id);
                          iconInputRef.current?.click();
                        }}
                        className="rounded-[12px]"
                      >
                        上传
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <input
                ref={iconInputRef}
                type="file"
                accept="image/*"
                onChange={handleIconUpload}
                className="hidden"
              />

              <p className="text-sm text-muted-foreground">
                💡 推荐使用图片URL，不占用本地存储
              </p>
            </div>
          </TabsContent>

          <TabsContent value="bubble" className="space-y-6 mt-6 fade-in">
            <div className="glass-card p-6 space-y-5 scale-in">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-[14px] glass-card flex items-center justify-center glow">
                  <Code className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold gradient-text">气泡样式</h3>
              </div>

              <div className="space-y-3">
                <Label htmlFor="bubbleCode" className="text-sm font-semibold">CSS 代码</Label>
                <p className="text-xs text-muted-foreground mb-2">
                  使用 .custom-bubble-user 和 .custom-bubble-character 类来自定义聊天气泡样式
                </p>
                <Textarea
                  id="bubbleCode"
                  placeholder={`.custom-bubble-user {\n  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);\n  color: white;\n  border-radius: 20px;\n  padding: 12px 16px;\n  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);\n}\n\n.custom-bubble-character {\n  background: rgba(255, 255, 255, 0.1);\n  backdrop-filter: blur(20px);\n  border: 1px solid rgba(255, 255, 255, 0.2);\n  border-radius: 20px;\n  padding: 12px 16px;\n}`}
                  value={bubbleCode}
                  onChange={(e) => setBubbleCode(e.target.value)}
                  rows={14}
                  className="glass-card font-mono text-xs rounded-[16px] border-white/30 custom-scrollbar leading-relaxed"
                />
              </div>

              <div className="glass-card p-5 space-y-4 rounded-[20px] border-white/30 ios-shadow">
                <Label className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  实时预览
                </Label>
                <style>{bubbleCode || bubblePreview}</style>
                <div className="p-4 space-y-4 rounded-[16px] bg-background/30">
                  <div className="flex justify-end">
                    <div className="custom-bubble-user max-w-[75%]">
                      <p className="text-sm">这是用户消息的预览效果</p>
                    </div>
                  </div>
                  <div className="flex justify-start">
                    <div className="custom-bubble-character max-w-[75%]">
                      <p className="text-sm">这是角色消息的预览效果</p>
                    </div>
                  </div>
                </div>
              </div>

              <Button
                onClick={saveBubbleCode}
                className="w-full h-12 glass-button glow rounded-[14px] font-semibold"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                保存并应用
              </Button>

              <p className="text-sm text-muted-foreground text-center">
                自定义 CSS 类名：.custom-bubble-user 和 .custom-bubble-character
              </p>
            </div>
          </TabsContent>

          <TabsContent value="font" className="space-y-6 mt-6 fade-in">
            <div className="glass-card p-6 space-y-5 scale-in">
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-[14px] glass-card flex items-center justify-center glow">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold gradient-text">自定义字体</h3>
              </div>

              {selectedFont && (
                <div className="glass-card p-4 rounded-[16px] space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold">当前字体</p>
                      <p className="text-lg font-bold mt-1" style={{ fontFamily: 'CustomFont' }}>{selectedFont}</p>
                      <p className="text-sm text-muted-foreground mt-2">示例文字 Example Text 123</p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={clearFont}
                      className="rounded-[12px]"
                    >
                      清除
                    </Button>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                <Label>上传字体文件</Label>
                <input
                  ref={fontInputRef}
                  type="file"
                  accept=".ttf,.otf,.woff,.woff2"
                  onChange={handleFontUpload}
                  className="hidden"
                />
                <Button
                  onClick={() => fontInputRef.current?.click()}
                  className="w-full glass-button h-12"
                  variant="outline"
                >
                  <Upload className="w-4 h-4 mr-2" />
                  选择字体文件
                </Button>
              </div>

              <p className="text-sm text-muted-foreground text-center">
                支持 .ttf, .otf, .woff, .woff2 格式<br/>
                字体将应用于整个应用界面
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PhoneFrame>
  );
};

export default Gallery;
