import { useState, useEffect } from 'react';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { storage } from '@/lib/storage';
import { MemoryFragment, Character } from '@/types';
import { Sparkles, Archive, Clock, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent } from '@/components/ui/dialog';

const Vestige = () => {
  const [fragments, setFragments] = useState<MemoryFragment[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [selectedCharId, setSelectedCharId] = useState<string>('');
  const [showGenerator, setShowGenerator] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [viewMode, setViewMode] = useState<'home' | 'museum'>('home');
  const [selectedTimeline, setSelectedTimeline] = useState<'🌑' | '🌓' | '🌕' | 'random'>('random');
  const [selectedType, setSelectedType] = useState<'note' | 'photo' | 'recording' | 'journal' | 'letter' | 'random'>('random');
  const [selectedFragment, setSelectedFragment] = useState<MemoryFragment | null>(null);

  useEffect(() => {
    setFragments(storage.getMemoryFragments());
    setCharacters(storage.getCharacters());
  }, []);

  const recentFragments = fragments
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 3);

  const groupedFragments = {
    note: fragments.filter(f => f.type === 'note'),
    photo: fragments.filter(f => f.type === 'photo'),
    recording: fragments.filter(f => f.type === 'recording'),
    journal: fragments.filter(f => f.type === 'journal'),
    letter: fragments.filter(f => f.type === 'letter'),
  };

  const timelineFragments = {
    '🌑': fragments.filter(f => f.emoji === '🌑'),
    '🌓': fragments.filter(f => f.emoji === '🌓'),
    '🌕': fragments.filter(f => f.emoji === '🌕'),
  };

  const generateFragment = async () => {
    if (!selectedCharId || selectedCharId === 'all') {
      toast.error('请先选择角色');
      return;
    }

    const character = characters.find(c => c.id === selectedCharId);
    if (!character) return;

    const sessions = storage.getChatSessions().filter(s => s.characterId === selectedCharId);
    const recentSession = sessions.sort((a, b) => b.createdAt - a.createdAt)[0];

    setGenerating(true);

    try {
      const apiSettings = storage.getApiSettings();
      if (!apiSettings?.apiKey || !apiSettings?.baseUrl) {
        toast.error('请先在主页配置API设置');
        setGenerating(false);
        return;
      }

      // 确定时间线和类型
      const relationshipEmojis = ['🌑', '🌓', '🌕'];
      const emoji = selectedTimeline === 'random' 
        ? relationshipEmojis[Math.floor(Math.random() * relationshipEmojis.length)]
        : selectedTimeline;
      
      const types: ('note' | 'photo' | 'recording' | 'journal' | 'letter')[] = ['note', 'photo', 'recording', 'journal', 'letter'];
      const fragmentType = selectedType === 'random'
        ? types[Math.floor(Math.random() * types.length)]
        : selectedType;

      const memoryContext = recentSession?.coreMemory 
        ? `\n\n# 核心记忆\n${recentSession.coreMemory}`
        : '';
      
      const recentMessages = recentSession?.messages.slice(-20) || [];
      const chatContext = recentMessages.length > 0
        ? `\n\n# 近期对话\n${recentMessages.map(m => `${m.sender === 'user' ? character.user.name : character.char.name}: ${m.content}`).join('\n')}`
        : '';

      let typeInstruction = '';
      let outputFormat = '';

      switch (fragmentType) {
        case 'note':
          typeInstruction = '生成一段撕下的笔记，内容碎片化，可以是短句、关键词或不成形的思考。';
          outputFormat = '📜|发现地点$\n『${emoji}时间段‖🔍物件状态』$\n🖋记忆正文（完整单段）$';
          break;
        case 'photo':
          typeInstruction = '生成一张附言的照片，描述照片画面并写下背后文字。';
          outputFormat = '📷|冲印信息$\n『${emoji}时间段‖🔍照片描述』$\n🖋背后文字（完整单段）$';
          break;
        case 'recording':
          typeInstruction = '生成一段独白录音，包含停顿、叹息等非语言声音标注。';
          outputFormat = '📼|标签或情境$\n『${emoji}时间段‖🔍录音环境与声音质感』$\n⏯️独白文字转述（完整单段）$';
          break;
        case 'journal':
          typeInstruction = '生成一篇日记本条目，结构完整、有叙事感的思考与记录。';
          outputFormat = '📔|日期或时期$\n『${emoji}时间段‖🔍物件状态』$\n🖋️日记正文（完整单段）$';
          break;
        case 'letter':
          typeInstruction = '生成一封信件。随机决定是写给用户、写给NPC、还是收到的信。';
          outputFormat = '💌/✉/📩|收件人或发件人$\n『${emoji}时间段‖🔍物件状态』$\n🖋️/📃信件正文（完整单段）$\n（如果是收到的信）🔻批注$';
          break;
      }

      const prompt = `你是${character.char.name}。请基于以下信息生成一段记忆碎片：

# 角色设定
${character.char.basicInfo}
${character.char.personality ? `性格：${character.char.personality}` : ''}

# 用户信息
${character.user.name || '用户'}
${character.user.basicInfo || ''}
${memoryContext}${chatContext}

# 任务
${typeInstruction}

使用emoji：${emoji} (🌑=遇见之前, 🌓=遇见到确认关系之间, 🌕=确认关系之后但非近期)

# 输出格式
严格按照以下格式输出，使用$符号分隔每个部分：
${outputFormat}

要求：
1. 内容必须是"非近期"时间线
2. 所有内容完整无换行，单一段落
3. 符合关系阶段的称呼和情感
4. 第一人称视角`;

      const response = await fetch(`${apiSettings.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiSettings.apiKey}`,
        },
        body: JSON.stringify({
          model: apiSettings.model,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.9,
        }),
      });

      if (!response.ok) throw new Error('生成失败');

      const data = await response.json();
      const generated = data.choices[0].message.content;

      const parts = generated.split('$').map((p: string) => p.trim());
      
      let newFragment: MemoryFragment;
      
      if (fragmentType === 'letter') {
        let letterType: 'to-user' | 'to-npc' | 'from-other' = 'to-user';
        if (parts[0].includes('📩')) letterType = 'from-other';
        else if (parts[0].includes('✉')) letterType = 'to-npc';
        
        newFragment = {
          id: Date.now().toString(),
          characterId: selectedCharId,
          type: fragmentType,
          emoji: emoji,
          location: parts[0].replace(/[📜📷📼📔💌✉📩]\|/, ''),
          timeInfo: parts[1].match(/『.*?』/)?.[0] || '',
          physicalState: parts[1].match(/🔍.*/)?.[0] || '',
          content: parts[2] || '',
          letterType,
          recipientOrSender: parts[0].split('|')[1]?.replace('致', '').replace('来自', ''),
          annotation: letterType === 'from-other' && parts[3] ? parts[3].replace('🔻', '') : undefined,
          createdAt: Date.now(),
        };
      } else {
        newFragment = {
          id: Date.now().toString(),
          characterId: selectedCharId,
          type: fragmentType,
          emoji: emoji,
          location: parts[0].replace(/[📜📷📼📔]\|/, ''),
          timeInfo: parts[1].match(/『.*?』/)?.[0] || '',
          physicalState: parts[1].match(/🔍.*/)?.[0] || '',
          content: parts[2] || '',
          createdAt: Date.now(),
        };
      }

      storage.addMemoryFragment(newFragment);
      setFragments(storage.getMemoryFragments());
      toast.success('记忆已抽取');
      setShowGenerator(false);
    } catch (error) {
      toast.error('生成失败，请检查API设置');
      console.error(error);
    } finally {
      setGenerating(false);
    }
  };

  const typeIcons: Record<string, string> = {
    note: '📜',
    photo: '📷',
    recording: '📼',
    journal: '📔',
    letter: '💌',
  };

  const typeColors: Record<string, string> = {
    note: 'from-amber-400/20 to-orange-400/20',
    photo: 'from-cyan-400/20 to-blue-400/20',
    recording: 'from-purple-400/20 to-pink-400/20',
    journal: 'from-green-400/20 to-emerald-400/20',
    letter: 'from-rose-400/20 to-pink-400/20',
  };

  return (
    <PhoneFrame title="Vestige" showBack>
      <div className="h-full flex flex-col relative overflow-hidden">
        {/* 全屏毛玻璃背景 */}
        <div className="absolute inset-0 gradient-bg" />
        
        <div className="relative z-10 h-full flex flex-col">
          {viewMode === 'home' ? (
            // 主界面
            <div className="flex-1 flex flex-col items-center justify-center p-8 space-y-8">
              {/* 主按钮 */}
              <button
                onClick={() => {
                  if (!selectedCharId || selectedCharId === 'all') {
                    toast.error('请先在博物馆模式选择角色');
                    setViewMode('museum');
                  } else {
                    setShowGenerator(true);
                  }
                }}
                className="glass-card px-16 py-8 rounded-[32px] ios-shadow-lg hover:scale-95 active:scale-92 smooth-transition group"
              >
                <div className="flex flex-col items-center gap-4">
                  <Sparkles className="w-16 h-16 text-primary group-hover:rotate-12 smooth-transition" />
                  <span className="text-2xl font-bold tracking-wide">抽取一段记忆</span>
                </div>
              </button>

              {/* 提示语 */}
              <p className="text-sm text-muted-foreground text-center max-w-xs">
                按下，即可提取他灵魂深处的遗迹。
              </p>

              {/* 最近记录 */}
              <div className="w-full max-w-md space-y-3 mt-12">
                <div className="flex items-center justify-between px-2">
                  <h3 className="text-sm font-semibold text-muted-foreground">最近抽取</h3>
                  <span className="text-xs text-muted-foreground">{recentFragments.length}/3</span>
                </div>
                <div className="space-y-2">
                  {recentFragments.length === 0 ? (
                    <div className="glass-card p-6 text-center text-sm text-muted-foreground">
                      暂无记忆
                    </div>
                  ) : (
                    recentFragments.map((frag) => (
                      <button
                        key={frag.id}
                        onClick={() => setSelectedFragment(frag)}
                        className="w-full glass-card p-4 rounded-[20px] hover:scale-[1.02] smooth-transition text-left"
                      >
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{typeIcons[frag.type]}</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium truncate">{frag.location}</p>
                            <p className="text-xs text-muted-foreground truncate">{frag.emoji} {frag.timeInfo}</p>
                          </div>
                          <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                        </div>
                      </button>
                    ))
                  )}
                </div>
              </div>

              {/* 进入博物馆按钮 */}
              <Button
                onClick={() => setViewMode('museum')}
                variant="outline"
                className="glass-button px-8 py-6 rounded-[20px] mt-8"
              >
                <Archive className="w-5 h-5 mr-2" />
                进入博物馆模式
              </Button>
            </div>
          ) : (
            // 博物馆模式
            <div className="flex-1 flex flex-col p-4">
              <div className="flex items-center justify-between mb-4">
                <Button
                  onClick={() => setViewMode('home')}
                  variant="ghost"
                  size="sm"
                  className="glass-button"
                >
                  ← 返回
                </Button>
                <h2 className="text-lg font-bold">博物馆</h2>
                <div className="w-16" />
              </div>

              <Tabs defaultValue="draw" className="flex-1 flex flex-col">
                <TabsList className="grid w-full grid-cols-3 glass-card p-1.5 mb-4">
                  <TabsTrigger value="draw" className="rounded-[14px] data-[state=active]:glass-button">抽取</TabsTrigger>
                  <TabsTrigger value="archive" className="rounded-[14px] data-[state=active]:glass-button">陈列</TabsTrigger>
                  <TabsTrigger value="timeline" className="rounded-[14px] data-[state=active]:glass-button">时间线</TabsTrigger>
                </TabsList>

                <TabsContent value="draw" className="flex-1 space-y-4 overflow-y-auto">
                  <div className="glass-card p-6 space-y-4">
                    <div className="space-y-2">
                      <label className="text-sm font-semibold">选择角色</label>
                      <Select value={selectedCharId} onValueChange={setSelectedCharId}>
                        <SelectTrigger className="glass-button">
                          <SelectValue placeholder="选择角色" />
                        </SelectTrigger>
                        <SelectContent>
                          {characters.map(char => (
                            <SelectItem key={char.id} value={char.id}>{char.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold">时间线</label>
                      <div className="grid grid-cols-4 gap-2">
                        {(['random', '🌑', '🌓', '🌕'] as const).map((t) => (
                          <button
                            key={t}
                            onClick={() => setSelectedTimeline(t)}
                            className={`glass-button p-3 rounded-[14px] text-center smooth-transition ${
                              selectedTimeline === t 
                                ? 'ring-4 ring-primary bg-primary/40 scale-110 shadow-lg shadow-primary/30' 
                                : 'opacity-50 hover:opacity-80'
                            }`}
                          >
                            <div className={`text-sm font-medium ${selectedTimeline === t ? 'text-primary font-extrabold scale-110' : ''} smooth-transition`}>
                              {t === 'random' ? '随机' : t}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-semibold">媒介类型</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['random', 'note', 'photo', 'recording', 'journal', 'letter'] as const).map((t) => (
                          <button
                            key={t}
                            onClick={() => setSelectedType(t)}
                            className={`glass-button p-3 rounded-[14px] text-center smooth-transition ${
                              selectedType === t 
                                ? 'ring-4 ring-primary bg-primary/40 scale-110 shadow-lg shadow-primary/30' 
                                : 'opacity-50 hover:opacity-80'
                            }`}
                          >
                            <div className={`text-xl mb-1 ${selectedType === t ? 'scale-125' : ''} smooth-transition`}>
                              {t === 'random' ? '🎲' : typeIcons[t]}
                            </div>
                            <div className={`text-xs ${selectedType === t ? 'text-primary font-extrabold' : ''}`}>
                              {t === 'random' ? '随机' : t}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>

                    <Button
                      onClick={generateFragment}
                      disabled={generating || !selectedCharId}
                      className="w-full py-6 glass-button glow"
                    >
                      <Sparkles className="w-5 h-5 mr-2" />
                      {generating ? '抽取中...' : '开始抽取'}
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="archive" className="flex-1 space-y-4 overflow-y-auto">
                  {Object.entries(groupedFragments).map(([type, frags]) => (
                    frags.length > 0 && (
                      <div key={type} className="space-y-2">
                        <div className="flex items-center gap-2 px-2">
                          <span className="text-lg">{typeIcons[type as keyof typeof typeIcons]}</span>
                          <h3 className="text-sm font-semibold">{type}</h3>
                          <span className="text-xs text-muted-foreground">({frags.length})</span>
                        </div>
                        <div className="space-y-2">
                          {frags.map((frag) => (
                            <button
                              key={frag.id}
                              onClick={() => setSelectedFragment(frag)}
                              className={`w-full glass-card bg-gradient-to-br ${typeColors[frag.type]} p-4 rounded-[20px] hover:scale-[1.02] smooth-transition text-left`}
                            >
                              <div className="flex items-start justify-between">
                                <div className="flex-1 min-w-0 space-y-1">
                                  <p className="text-sm font-medium">{frag.location}</p>
                                  <p className="text-xs text-muted-foreground">{frag.emoji} {frag.timeInfo}</p>
                                </div>
                                <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 ml-2" />
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )
                  ))}
                  {fragments.length === 0 && (
                    <div className="glass-card p-8 text-center text-sm text-muted-foreground">
                      暂无记忆碎片
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="timeline" className="flex-1 space-y-4 overflow-y-auto">
                  {(['🌑', '🌓', '🌕'] as const).map((emoji) => (
                    timelineFragments[emoji].length > 0 && (
                      <div key={emoji} className="space-y-2">
                        <div className="glass-card p-4 rounded-[20px]">
                          <div className="flex items-center gap-3 mb-3">
                            <Clock className="w-5 h-5" />
                            <h3 className="text-base font-bold">{emoji} {emoji === '🌑' ? '过去' : emoji === '🌓' ? '相遇至恋前' : '恋人后非近期'}</h3>
                            <span className="text-xs text-muted-foreground">({timelineFragments[emoji].length})</span>
                          </div>
                          <div className="space-y-2">
                            {timelineFragments[emoji].map((frag) => (
                              <button
                                key={frag.id}
                                onClick={() => setSelectedFragment(frag)}
                                className="w-full glass-button p-3 rounded-[14px] hover:scale-[1.02] smooth-transition text-left"
                              >
                                <div className="flex items-center gap-2">
                                  <span className="text-lg">{typeIcons[frag.type]}</span>
                                  <div className="flex-1 min-w-0">
                                    <p className="text-xs font-medium truncate">{frag.location}</p>
                                    <p className="text-xs text-muted-foreground truncate">{frag.timeInfo}</p>
                                  </div>
                                </div>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    )
                  ))}
                  {fragments.length === 0 && (
                    <div className="glass-card p-8 text-center text-sm text-muted-foreground">
                      暂无时间线记录
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </div>

      {/* 记忆阅读模式 */}
      <Dialog open={!!selectedFragment} onOpenChange={() => setSelectedFragment(null)}>
        <DialogContent className="max-w-[90vw] sm:max-w-md glass-card border-white/30">
          {selectedFragment && (
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{typeIcons[selectedFragment.type]}</span>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">{selectedFragment.location}</h3>
                  <p className="text-sm text-muted-foreground">{selectedFragment.emoji} {selectedFragment.timeInfo}</p>
                </div>
              </div>
              <div className="glass-card p-4 rounded-[16px] space-y-2">
                <p className="text-xs text-muted-foreground">{selectedFragment.physicalState}</p>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{selectedFragment.content}</p>
                {selectedFragment.annotation && (
                  <div className="border-t pt-2 mt-2">
                    <p className="text-xs text-muted-foreground">🔻 {selectedFragment.annotation}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PhoneFrame>
  );
};

export default Vestige;