import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { storage } from '@/lib/storage';
import { ChatSession, Character, Message, WorldBook } from '@/types';
import { Send, Settings as SettingsIcon, User, Image as ImageIcon, Sparkles, Plus, Banknote, Trash2, Eye, EyeOff, Brain, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Switch } from '@/components/ui/switch';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';

const ChatRoom = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [session, setSession] = useState<ChatSession | null>(null);
  const [character, setCharacter] = useState<Character | null>(null);
  const [input, setInput] = useState('');
  const [pendingMessages, setPendingMessages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showAttachments, setShowAttachments] = useState(false);
  const [localApiSettings, setLocalApiSettings] = useState<{
    baseUrl: string;
    apiKey: string;
    model: string;
    temperature?: number;
    contextRounds?: number;
    mode?: 'online' | 'offline';
  }>({
    baseUrl: 'https://api.openai.com/v1',
    apiKey: '',
    model: 'gpt-3.5-turbo',
    temperature: 0.8,
    contextRounds: 10,
    mode: 'online',
  });
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [worldBooks, setWorldBooks] = useState<WorldBook[]>([]);
  const [displaySettings, setDisplaySettings] = useState({ showUserAvatar: true, showCharAvatar: true });
  const [coreMemory, setCoreMemory] = useState('');
  const [coreMemoryTriggerRounds, setCoreMemoryTriggerRounds] = useState(20);
  const [extractingMemory, setExtractingMemory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const sessions = storage.getChatSessions();
    const currentSession = sessions.find((s) => s.id === id);
    if (currentSession) {
      setSession(currentSession);
      const char = storage.getCharacters().find((c) => c.id === currentSession.characterId);
      setCharacter(char || null);
      
      // 加载显示设置
      if (currentSession.displaySettings) {
        setDisplaySettings(currentSession.displaySettings);
      }
      
      // 加载核心记忆
      if (currentSession.coreMemory) {
        setCoreMemory(currentSession.coreMemory);
      }
      if (currentSession.coreMemoryTriggerRounds) {
        setCoreMemoryTriggerRounds(currentSession.coreMemoryTriggerRounds);
      }
      
      // 总是从全局设置加载API配置，会话级别的配置仅用于覆盖
      const globalSettings = storage.getApiSettings();
      if (globalSettings) {
        setLocalApiSettings({
          baseUrl: globalSettings.baseUrl,
          apiKey: globalSettings.apiKey,
          model: globalSettings.model,
          temperature: globalSettings.temperature || 0.8,
          contextRounds: globalSettings.contextRounds || 10,
          mode: globalSettings.mode || 'online',
        });
      }
      
      // 如果会话有自己的API设置，则覆盖
      if (currentSession.apiSettings) {
        setLocalApiSettings(currentSession.apiSettings);
      }
    } else {
      toast.error('聊天不存在');
      navigate('/chat');
    }
    
    // 加载世界书
    setWorldBooks(storage.getWorldBooks());
  }, [id, navigate]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [session?.messages, pendingMessages]);

  const handleWallpaperUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && id && session) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const wallpaperData = reader.result as string;
        storage.updateChatSession(id, { wallpaper: wallpaperData });
        const updatedSession = { ...session, wallpaper: wallpaperData };
        setSession(updatedSession);
        toast.success('壁纸已更新，关闭对话框即可查看');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && id && session) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageMessage: Message = {
          id: Date.now().toString(),
          content: file.name,
          sender: 'user',
          timestamp: Date.now(),
          type: 'image',
          imageUrl: reader.result as string,
        };
        const updatedMessages = [...session.messages, imageMessage];
        storage.updateChatSession(id, { messages: updatedMessages });
        setSession({ ...session, messages: updatedMessages });
        toast.success('图片已发送');
        setShowAttachments(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const [transferAmount, setTransferAmount] = useState('');
  const [showTransferDialog, setShowTransferDialog] = useState(false);

  const handleTransfer = () => {
    if (!id || !session || !transferAmount || isNaN(Number(transferAmount))) {
      toast.error('请输入有效金额');
      return;
    }
    
    const transferMessage: Message = {
      id: Date.now().toString(),
      content: `转账 ¥${transferAmount}`,
      sender: 'user',
      timestamp: Date.now(),
      type: 'transfer',
      transferAmount: Number(transferAmount),
    };
    const updatedMessages = [...session.messages, transferMessage];
    storage.updateChatSession(id, { messages: updatedMessages });
    setSession({ ...session, messages: updatedMessages });
    toast.success('转账消息已发送');
    setShowAttachments(false);
    setShowTransferDialog(false);
    setTransferAmount('');
  };

  const saveApiSettings = () => {
    if (!localApiSettings.apiKey || !localApiSettings.baseUrl || !localApiSettings.model) {
      toast.error('请填写完整的API设置');
      return;
    }
    
    if (id) {
      storage.updateChatSession(id, { apiSettings: localApiSettings });
      setSession(prev => prev ? { ...prev, apiSettings: localApiSettings } : null);
      toast.success('API设置已保存');
    }
  };

  const clearMemory = () => {
    if (!id || !session) return;
    if (confirm('确定清空所有聊天记忆吗？此操作不可撤销。')) {
      storage.updateChatSession(id, { messages: [] });
      setSession({ ...session, messages: [] });
      toast.success('聊天记忆已清空');
    }
  };

  const toggleWorldBook = (bookId: string) => {
    if (!id || !session) return;
    const current = session.selectedWorldBooks || [];
    const updated = current.includes(bookId)
      ? current.filter(id => id !== bookId)
      : [...current, bookId];
    storage.updateChatSession(id, { selectedWorldBooks: updated });
    setSession({ ...session, selectedWorldBooks: updated });
  };

  const saveDisplaySettings = () => {
    if (!id) return;
    storage.updateChatSession(id, { displaySettings });
    setSession(prev => prev ? { ...prev, displaySettings } : null);
    toast.success('显示设置已保存');
  };

  const saveCoreMemory = () => {
    if (!id) return;
    storage.updateChatSession(id, { coreMemory, coreMemoryTriggerRounds });
    setSession(prev => prev ? { ...prev, coreMemory, coreMemoryTriggerRounds } : null);
    toast.success('核心记忆已保存');
  };

  const extractCoreMemory = async () => {
    if (!session || !character || !id) return;
    
    const effectiveSettings = session.apiSettings || localApiSettings;
    if (!effectiveSettings.apiKey || !effectiveSettings.baseUrl) {
      toast.error('请先配置API设置');
      return;
    }

    setExtractingMemory(true);
    
    try {
      const recentMessages = session.messages.slice(-coreMemoryTriggerRounds * 2);
      const chatHistory = recentMessages.map(m => 
        `${m.sender === 'user' ? character.user.name : character.char.name}: ${m.content}`
      ).join('\n');

      const prompt = `请对以下聊天记录进行核心记忆总结。

# 聊天记录
${chatHistory}

# 总结要求
1. 使用自然语言，概括关键节点
2. 不重复总结已有的核心记忆内容
3. 用客观视角描述事件，如同日志记录
4. 使用第三人称称呼${character.user.name}，而不是"你"
5. 每个事件前如有时间信息，需标明时间
6. 不掺杂情感和评价
7. 不换行的情况下，可用空段分隔不同事件

# 已有核心记忆
${coreMemory || '（无）'}

# 示例输出格式
x月x日，${character.user.name}参加故事AI比赛获得第一名。 x月x日，${character.user.name}与${character.char.name}完成了初次任务。

请只输出新的核心记忆总结内容：`;

      const response = await fetch(`${effectiveSettings.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${effectiveSettings.apiKey}`,
        },
        body: JSON.stringify({
          model: effectiveSettings.model,
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.3,
        }),
      });

      if (!response.ok) throw new Error('提取失败');

      const data = await response.json();
      const newMemory = data.choices[0].message.content.trim();
      
      const updatedMemory = coreMemory 
        ? `${coreMemory} ${newMemory}`
        : newMemory;
      
      setCoreMemory(updatedMemory);
      storage.updateChatSession(id, { coreMemory: updatedMemory });
      setSession(prev => prev ? { ...prev, coreMemory: updatedMemory } : null);
      toast.success('核心记忆已提取');
    } catch (error) {
      toast.error('提取失败，请检查API设置');
      console.error(error);
    } finally {
      setExtractingMemory(false);
    }
  };

  const fetchModels = async () => {
    if (!localApiSettings.apiKey || !localApiSettings.baseUrl) {
      toast.error('请先填写API Key和Base URL');
      return;
    }

    try {
      const response = await fetch(`${localApiSettings.baseUrl}/models`, {
        headers: {
          'Authorization': `Bearer ${localApiSettings.apiKey}`,
        },
      });

      if (!response.ok) throw new Error('获取模型列表失败');

      const data = await response.json();
      const modelIds = data.data.map((m: any) => m.id);
      setAvailableModels(modelIds);
      toast.success(`已获取 ${modelIds.length} 个模型`);
    } catch (error) {
      toast.error('获取模型失败，请检查API设置');
      console.error(error);
    }
  };

  const addPendingMessage = () => {
    if (!input.trim()) return;
    setPendingMessages([...pendingMessages, input]);
    setInput('');
  };

  const removePendingMessage = (index: number) => {
    setPendingMessages(pendingMessages.filter((_, i) => i !== index));
  };

  const generateResponse = async () => {
    if (pendingMessages.length === 0 || !session || !character || !id) {
      toast.error('请先输入消息');
      return;
    }

    // 优先使用会话的API设置，否则尝试全局设置
    let effectiveSettings = session.apiSettings || localApiSettings;
    
    // 如果仍然没有API设置，尝试重新加载全局设置
    if (!effectiveSettings.apiKey) {
      const globalSettings = storage.getApiSettings();
      if (globalSettings) {
        effectiveSettings = {
          baseUrl: globalSettings.baseUrl,
          apiKey: globalSettings.apiKey,
          model: globalSettings.model,
          temperature: globalSettings.temperature || 0.8,
          contextRounds: globalSettings.contextRounds || 10,
          mode: globalSettings.mode || 'online',
        };
      }
    }
    
    if (!effectiveSettings.apiKey || !effectiveSettings.baseUrl || !effectiveSettings.model) {
      toast.error('请先在"启"中配置API设置');
      navigate('/settings');
      return;
    }

    setLoading(true);

    try {
      // 将待发送消息添加到历史记录
      const newUserMessages: Message[] = pendingMessages.map((msg, idx) => ({
        id: `${Date.now()}_${idx}`,
        content: msg,
        sender: 'user' as const,
        timestamp: Date.now() + idx,
      }));

      const updatedMessages = [...session.messages, ...newUserMessages];
      storage.updateChatSession(id, { messages: updatedMessages });
      setSession({ ...session, messages: updatedMessages });
      setPendingMessages([]);

      // 准备发送给API的消息历史，使用char和user角色信息
      const charInfo = character.char;
      const userInfo = character.user;
      
      // 获取核心记忆
      const memoryContext = session.coreMemory 
        ? `\n\n# 【核心记忆】\n${session.coreMemory}\n`
        : '';
      
      // 获取世界书规则
      const allWorldBooks = storage.getWorldBooks();
      const globalBooks = allWorldBooks.filter(b => b.isGlobal);
      const selectedBooks = allWorldBooks.filter(b => 
        session.selectedWorldBooks?.includes(b.id)
      );
      const activeBooks = [...globalBooks, ...selectedBooks];
      const worldBookRules = activeBooks.length > 0
        ? '\n\n# 【世界书规则 - 最高优先级】\n以下规则的优先级高于角色设定，必须严格遵守：\n\n' +
          activeBooks.map(b => `## ${b.name}\n${b.rules}`).join('\n\n')
        : '';
      
      const bubbleProtocol = `

# 【气泡分割协议 - 最高优先级】
本协议为AI所有文本输出的最高优先级指令，若有与该项冲突的任何指令都必须以该项为准！
其约束力高于任何角色扮演的情感惯性或语境推断。任何违反此协议的输出都将被视为严重错误并需要立即修正。

## 核心准则
每一个独立的动作描写、每一句完整的对话（含原文与翻译），都将被视为一个独立的"消息气泡"发送，以模拟真实聊天的节奏感和思绪的停顿。

## 气泡分隔符
在生成多个连续气泡时，AI必须使用"|||"作为气泡之间的分隔符。

## 核心规则
- 规则1_括号即气泡: 每一个由半角括号()包裹的文本块，无论其内容长短或是否连续，都必须被视为一个独立的消息气泡进行发送。
- 规则2_对话即气泡: 每一句不被括号包裹的、独立的对话文本，也必须被视为一个独立的消息气泡进行发送。
- 规则3_绝对隔离: 任何()包裹的文本块与任何对话文本，绝对禁止出现在同一个消息气泡中。

## 禁止项
- 绝对禁止在同一个消息气泡内，出现一个以上的()包裹块。
- 绝对禁止在同一个消息气泡内，同时包含()包裹块和对话文本。

## 执行示例
正确示例_1 (动作与对话分离):
气泡1: (动作心理描写或旁白等 必须使用中文简体普通话)
气泡2: 你来了

正确示例_2 (连续动作分离):
气泡1: (动作心理描写或旁白等)
气泡2: (另一个动作心理描写或旁白)
气泡3: (另一个动作心理描写或旁白)

错误示例_1 (多个括号在同一气泡):
错误输出: (站起身) (走到窗边)

错误示例_2 (动作与对话混合):
错误输出: (笑了笑) 你好啊

## 输出格式
使用"|||"分隔每个气泡。例如：
(微笑着走过来)|||你好呀|||今天过得怎么样？|||(轻轻拍了拍你的肩膀)
`;
      
      const modeInstruction = (effectiveSettings.mode || 'online') === 'online' 
        ? '\n\n# 【对话模式：线上聊天】\n你正在进行线上文字对话，只需要输出对话内容，不要有任何动作描写、心理描写或旁白。保持自然的聊天风格。'
        : '\n\n# 【对话模式：线下面对面】\n你正在模拟面对面交流，需要输出对话内容、动作描写、心理描写和旁白。用半角括号()标注动作和心理活动。';
      
      const systemPrompt = `${worldBookRules}${memoryContext}

# 角色设定
你现在要扮演：${charInfo.name}
${charInfo.basicInfo}
${charInfo.profession ? `职业：${charInfo.profession}` : ''}
${charInfo.age ? `年龄：${charInfo.age}` : ''}
${charInfo.personality ? `性格：${charInfo.personality}` : ''}

# 对话对象
对方是：${userInfo.name || '用户'}
${userInfo.basicInfo || ''}
${userInfo.profession ? `职业：${userInfo.profession}` : ''}
${userInfo.age ? `年龄：${userInfo.age}` : ''}
${userInfo.personality ? `性格：${userInfo.personality}` : ''}

请严格按照以上设定回复，保持角色一致性。${modeInstruction}${bubbleProtocol}`;

      // 使用最近N轮对话作为上下文，上限500轮
      const maxRounds = Math.min(effectiveSettings.contextRounds || 10, 500);
      const contextMessages = updatedMessages.slice(-maxRounds * 2);
      
      const response = await fetch(`${effectiveSettings.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${effectiveSettings.apiKey}`,
        },
        body: JSON.stringify({
          model: effectiveSettings.model,
          messages: [
            { role: 'system', content: systemPrompt },
            ...contextMessages.map(m => ({
              role: m.sender === 'user' ? 'user' : 'assistant',
              content: m.content,
            })),
          ],
          temperature: effectiveSettings.temperature || 0.8,
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('API错误:', errorText);
        throw new Error('发送失败');
      }

      const data = await response.json();
      const aiContent = data.choices[0].message.content;
      
      // 将AI回复按|||分割成多条消息
      const messageParts = aiContent.split('|||').map((part: string) => part.trim()).filter((part: string) => part);
      
      const aiMessages: Message[] = messageParts.map((content: string, idx: number) => ({
        id: `${Date.now() + 1000 + idx}`,
        content,
        sender: 'char' as const,
        timestamp: Date.now() + idx,
      }));

      const finalMessages = [...updatedMessages, ...aiMessages];
      storage.updateChatSession(id, { messages: finalMessages });
      setSession({ ...session, messages: finalMessages });
    } catch (error) {
      toast.error('发送失败，请检查API设置');
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  // 应用自定义气泡样式
  useEffect(() => {
    const bubbleCode = localStorage.getItem('bubble_code');
    if (bubbleCode) {
      const styleId = 'custom-bubble-style';
      let styleElement = document.getElementById(styleId) as HTMLStyleElement;
      
      if (!styleElement) {
        styleElement = document.createElement('style');
        styleElement.id = styleId;
        document.head.appendChild(styleElement);
      }
      
      styleElement.textContent = bubbleCode;
    }
  }, []);

  if (!session || !character) return null;

  return (
    <PhoneFrame showBack={false}>
      <div className="h-full flex flex-col relative">
        {/* 背景壁纸层 */}
        {session?.wallpaper && (
          <>
            <div 
              className="absolute inset-0 bg-cover bg-center transition-all duration-500 z-0"
              style={{ backgroundImage: `url(${session.wallpaper})` }}
            />
            <div className="absolute inset-0 bg-background/30 backdrop-blur-sm z-0" />
          </>
        )}
        
        <div className="relative z-10 h-full flex flex-col">
          {/* 自定义顶栏 - 在壁纸层内 */}
          <div className="h-14 bg-black/10 backdrop-blur-xl flex items-center justify-between px-4 border-b border-white/20 rounded-b-[16px]">
            <div className="flex items-center gap-2 min-w-0 flex-1">
              <button
                onClick={() => navigate(-1)}
                className="p-2 glass-button rounded-[12px] smooth-transition hover:scale-105 active:scale-95"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
              <h1 className="text-lg font-semibold truncate">{character.char.name}</h1>
            </div>
            <Dialog open={showSettings} onOpenChange={setShowSettings}>
              <DialogTrigger asChild>
                <Button size="sm" variant="ghost">
                  <SettingsIcon className="w-4 h-4" />
                </Button>
              </DialogTrigger>
          <DialogContent className="w-[85vw] max-w-[400px] rounded-[28px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">聊天设置</DialogTitle>
              <DialogDescription className="sr-only">管理聊天的各项设置</DialogDescription>
            </DialogHeader>
            <Tabs defaultValue="advanced" className="w-full">
              <TabsList className="grid w-full grid-cols-4 p-1 rounded-2xl">
                <TabsTrigger value="advanced" className="text-xs rounded-xl">高级</TabsTrigger>
                <TabsTrigger value="display" className="text-xs rounded-xl">显示</TabsTrigger>
                <TabsTrigger value="worldbook" className="text-xs rounded-xl">世界书</TabsTrigger>
                <TabsTrigger value="wallpaper" className="text-xs rounded-xl">壁纸</TabsTrigger>
              </TabsList>

              <div className="mt-4 space-y-4 max-h-[55vh] overflow-y-auto pr-2 custom-scrollbar">
                <TabsContent value="advanced" className="space-y-3 mt-0">
                <div className="space-y-2">
                  <Label htmlFor="temperature">AI温度 ({localApiSettings.temperature})</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">0</span>
                    <input
                      id="temperature"
                      type="range"
                      min="0"
                      max="2"
                      step="0.1"
                      value={localApiSettings.temperature}
                      onChange={(e) => setLocalApiSettings({ ...localApiSettings, temperature: parseFloat(e.target.value) })}
                      className="flex-1"
                    />
                    <span className="text-xs text-muted-foreground">2</span>
                  </div>
                  <p className="text-xs text-muted-foreground">温度越高，回复越随机创意；温度越低，回复越稳定准确</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contextRounds">上下文记忆轮数 ({localApiSettings.contextRounds}，上限500)</Label>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-muted-foreground">1</span>
                    <input
                      id="contextRounds"
                      type="range"
                      min="1"
                      max="500"
                      step="1"
                      value={localApiSettings.contextRounds}
                      onChange={(e) => setLocalApiSettings({ ...localApiSettings, contextRounds: parseInt(e.target.value) })}
                      className="flex-1"
                    />
                    <span className="text-xs text-muted-foreground">500</span>
                  </div>
                  <p className="text-xs text-muted-foreground">AI会记住最近N轮对话（1轮=1次你的消息+1次AI回复）</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mode">对话模式</Label>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <p className="font-medium">{localApiSettings.mode === 'online' ? '线上聊天' : '线下面对面'}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {localApiSettings.mode === 'online' 
                          ? '只输出对话内容，模拟手机聊天' 
                          : '输出对话+动作+心理描写，模拟面对面交流'}
                      </p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLocalApiSettings({ 
                        ...localApiSettings, 
                        mode: localApiSettings.mode === 'online' ? 'offline' : 'online' 
                      })}
                    >
                      切换
                    </Button>
                  </div>
                </div>

                <div className="pt-4 border-t space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Brain className="w-4 h-4" />
                      <Label>核心记忆</Label>
                    </div>
                    <Textarea
                      placeholder="核心记忆会自动从聊天中提取，也可以手动编辑..."
                      value={coreMemory}
                      onChange={(e) => setCoreMemory(e.target.value)}
                      className="min-h-[100px]"
                    />
                    <div className="flex items-center justify-between">
                      <Label className="text-xs text-muted-foreground">
                        每 {coreMemoryTriggerRounds} 轮对话后可提取
                      </Label>
                      <Input
                        type="number"
                        min="5"
                        max="100"
                        value={coreMemoryTriggerRounds}
                        onChange={(e) => setCoreMemoryTriggerRounds(parseInt(e.target.value) || 20)}
                        className="w-20 h-8"
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        onClick={extractCoreMemory} 
                        disabled={extractingMemory || !session?.messages.length}
                        className="flex-1"
                        variant="outline"
                      >
                        {extractingMemory ? '提取中...' : '提取核心记忆'}
                      </Button>
                      <Button onClick={saveCoreMemory} className="flex-1">
                        保存
                      </Button>
                    </div>
                  </div>

                  <Button onClick={clearMemory} variant="destructive" className="w-full">
                    <Trash2 className="w-4 h-4 mr-2" />
                    清空所有聊天
                  </Button>
                </div>
                </TabsContent>

                <TabsContent value="display" className="space-y-3 mt-0">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <Label htmlFor="show-user-avatar">显示我的头像</Label>
                    <Switch
                      id="show-user-avatar"
                      checked={displaySettings.showUserAvatar}
                      onCheckedChange={(checked) => setDisplaySettings({ ...displaySettings, showUserAvatar: checked })}
                    />
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <Label htmlFor="show-char-avatar">显示角色头像</Label>
                    <Switch
                      id="show-char-avatar"
                      checked={displaySettings.showCharAvatar}
                      onCheckedChange={(checked) => setDisplaySettings({ ...displaySettings, showCharAvatar: checked })}
                    />
                  </div>
                </div>
                <Button onClick={saveDisplaySettings} className="w-full">
                  保存显示设置
                </Button>
                </TabsContent>

                <TabsContent value="worldbook" className="space-y-3 mt-0">
                <div className="space-y-3">
                  {worldBooks.length === 0 ? (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      还没有世界书，去创建一个吧
                    </p>
                  ) : (
                    worldBooks.map((book) => {
                      const isGlobal = book.isGlobal;
                      const isSelected = session?.selectedWorldBooks?.includes(book.id);
                      return (
                        <div key={book.id} className="flex items-start gap-3 p-3 border rounded-lg">
                          <Checkbox
                            id={`book-${book.id}`}
                            checked={isGlobal || isSelected}
                            disabled={isGlobal}
                            onCheckedChange={() => toggleWorldBook(book.id)}
                          />
                          <div className="flex-1">
                            <Label htmlFor={`book-${book.id}`} className="font-medium">
                              {book.name}
                              {isGlobal && <span className="text-xs text-primary ml-2">(全局)</span>}
                            </Label>
                            <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                              {book.rules}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
                </TabsContent>

                <TabsContent value="wallpaper" className="space-y-3 mt-0">
                <div>
                  {session?.wallpaper ? (
                    <div className="space-y-3">
                      <div className="relative rounded-2xl overflow-hidden border-2">
                        <img 
                          src={session.wallpaper} 
                          alt="当前壁纸" 
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                          <p className="text-white text-sm font-medium">当前壁纸</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <label className="cursor-pointer">
                      <div className="border-2 border-dashed rounded-lg p-6 text-center hover:bg-muted/50 transition-colors">
                        <ImageIcon className="w-8 h-8 mx-auto mb-2 text-muted-foreground" />
                        <p className="text-sm text-muted-foreground">点击上传图片</p>
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleWallpaperUpload}
                        className="hidden"
                      />
                    </label>
                  )}
                </div>
                {session?.wallpaper && (
                  <div className="flex gap-2">
                    <label className="flex-1">
                      <Button variant="outline" size="sm" className="w-full" asChild>
                        <span>更换壁纸</span>
                      </Button>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleWallpaperUpload}
                        className="hidden"
                      />
                    </label>
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        if (id) {
                          storage.updateChatSession(id, { wallpaper: undefined });
                          setSession({ ...session, wallpaper: undefined });
                          toast.success('壁纸已移除');
                        }
                      }}
                    >
                      移除壁纸
                    </Button>
                  </div>
                )}
                </TabsContent>
              </div>
            </Tabs>
          </DialogContent>
        </Dialog>
      </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {/* 已发送的消息 - iOS 风格气泡 */}
          {session.messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-2 items-end fade-in ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'char' && displaySettings.showCharAvatar && character && (
                <Avatar className="w-10 h-10 flex-shrink-0 ios-shadow-sm">
                  <AvatarImage src={character.char.avatar} />
                  <AvatarFallback className="glass-card text-sm">{character.char.name[0]}</AvatarFallback>
                </Avatar>
              )}
              <div
                className={`max-w-[68%] rounded-[20px] px-3.5 py-3 smooth-transition scale-in backdrop-blur-3xl border ios-shadow-lg ${
                  msg.sender === 'user'
                    ? 'custom-bubble-user bg-white/15 border-white/50 text-white shadow-lg'
                    : 'custom-bubble-character bg-black/15 border-white/30 text-foreground shadow-lg highlight-top'
                }`}
              >
                {msg.type === 'image' && msg.imageUrl ? (
                  <div className="space-y-2">
                    <img src={msg.imageUrl} alt={msg.content} className="rounded-lg max-w-full h-auto" />
                    <p className="text-xs opacity-80">{msg.content}</p>
                  </div>
                ) : msg.type === 'transfer' && msg.transferAmount ? (
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-full bg-background/20 flex items-center justify-center">
                      <Banknote className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">转账</p>
                      <p className="text-lg font-bold">¥{msg.transferAmount}</p>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.content}</p>
                )}
              </div>
              {msg.sender === 'user' && displaySettings.showUserAvatar && character && (
                <Avatar className="w-10 h-10 flex-shrink-0 ios-shadow-sm">
                  <AvatarImage src={character.user.avatar} />
                  <AvatarFallback className="glass-card text-sm">{character.user.name?.[0] || 'U'}</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}

          {/* 待发送的消息 - 毛玻璃效果 */}
          {pendingMessages.map((msg, idx) => (
            <div key={`pending-${idx}`} className="flex justify-end fade-in">
              <div
                className="max-w-[75%] rounded-[18px] px-4 py-3 glass-card border-2 border-dashed border-primary/30 cursor-pointer hover:scale-[1.02] smooth-transition"
                onClick={() => removePendingMessage(idx)}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg}</p>
                <p className="text-xs mt-1 opacity-60">点击删除</p>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start fade-in">
              <div className="glass-card rounded-[18px] px-4 py-3 ios-shadow">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                  <div className="w-2 h-2 bg-primary/70 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* 输入区域 - 毛玻璃效果 */}
        <div className="p-4 bg-black/10 backdrop-blur-xl border-t border-white/20 space-y-2 highlight-top rounded-t-[16px]">
          {pendingMessages.length > 0 && (
            <div className="flex items-center justify-between text-sm glass-card px-4 py-2.5 rounded-[14px] smooth-transition">
              <span className="font-medium">待发送: {pendingMessages.length} 条消息</span>
              <Button
                size="sm"
                onClick={generateResponse}
                disabled={loading}
                className="h-8 rounded-[10px] glass-button"
              >
                <Sparkles className="w-4 h-4 mr-1" />
                生成回复
              </Button>
            </div>
          )}
          <div className="flex gap-2">
            <Dialog open={showAttachments} onOpenChange={setShowAttachments}>
              <DialogTrigger asChild>
                <Button size="icon" variant="ghost" className="rounded-[12px] glass-button">
                  <Plus className="w-5 h-5" />
                </Button>
              </DialogTrigger>
              <DialogContent className="w-[85vw] max-w-[400px] rounded-[28px]">
                <DialogHeader>
                  <DialogTitle className="text-lg font-bold">发送附件</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      fileInputRef.current?.click();
                      setShowAttachments(false);
                    }}
                    className="glass-button rounded-[20px] p-6 flex flex-col items-center gap-3 hover:scale-95 active:scale-92 smooth-transition"
                  >
                    <div className="w-12 h-12 rounded-[16px] glass-card flex items-center justify-center glow">
                      <ImageIcon className="w-6 h-6 text-primary" />
                    </div>
                    <span className="text-sm font-medium">图片</span>
                  </button>
                  <button
                    onClick={() => {
                      setShowAttachments(false);
                      setShowTransferDialog(true);
                    }}
                    className="glass-button rounded-[20px] p-6 flex flex-col items-center gap-3 hover:scale-95 active:scale-92 smooth-transition"
                  >
                    <div className="w-12 h-12 rounded-[16px] glass-card flex items-center justify-center glow">
                      <Banknote className="w-6 h-6 text-primary" />
                    </div>
                    <span className="text-sm font-medium">转账</span>
                  </button>
                </div>
              </DialogContent>
            </Dialog>
            
            {/* 转账对话框 */}
            <Dialog open={showTransferDialog} onOpenChange={setShowTransferDialog}>
              <DialogContent className="w-[85vw] max-w-[400px] rounded-[28px]">
                <DialogHeader>
                  <DialogTitle className="text-xl font-bold gradient-text">发起转账</DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <div className="space-y-3">
                    <Label htmlFor="amount" className="text-sm font-semibold">转账金额</Label>
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-2xl font-bold text-primary">¥</span>
                      <Input
                        id="amount"
                        type="number"
                        placeholder="0.00"
                        value={transferAmount}
                        onChange={(e) => setTransferAmount(e.target.value)}
                        className="glass-card rounded-[16px] pl-12 pr-4 h-16 text-2xl font-bold text-center border-white/30"
                      />
                    </div>
                  </div>
                  <Button
                    onClick={handleTransfer}
                    disabled={!transferAmount || isNaN(Number(transferAmount))}
                    className="w-full h-14 glass-button glow rounded-[16px] text-lg font-semibold"
                  >
                    <Banknote className="w-5 h-5 mr-2" />
                    确认转账
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  addPendingMessage();
                }
              }}
              placeholder="输入消息（Enter添加到待发送）..."
              disabled={loading}
              className="flex-1 glass-card rounded-[14px] border-white/20 dark:border-white/10"
            />
            <Button 
              onClick={addPendingMessage} 
              disabled={loading || !input.trim()} 
              size="icon"
              className="rounded-[12px] glass-button ios-shadow"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </div>
        </div>
      </div>
    </PhoneFrame>
  );
};

export default ChatRoom;
