import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Plus, User, Edit } from 'lucide-react';
import { storage } from '@/lib/storage';
import { Character } from '@/types';

const Characters = () => {
  const navigate = useNavigate();
  const [characters, setCharacters] = useState<Character[]>([]);

  useEffect(() => {
    setCharacters(storage.getCharacters());
  }, []);

  return (
    <PhoneFrame
      title="序 - 人设档案"
      showBack
      headerRight={
        <Button size="sm" onClick={() => navigate('/characters/create')}>
          <Plus className="w-4 h-4 mr-1" />
          创建
        </Button>
      }
    >
      <div className="p-4 space-y-3 min-h-full bg-background/30 backdrop-blur-md">
        {characters.length === 0 ? (
          <div className="text-center py-12">
            <User className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
            <p className="text-muted-foreground mb-4">还没有创建任何角色档案</p>
            <Button onClick={() => navigate('/characters/create')}>
              创建第一个角色档案
            </Button>
          </div>
        ) : (
          characters.map((char) => (
            <Card
              key={char.id}
              className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => navigate(`/characters/${char.id}`)}
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                  {char.char.avatar ? (
                    <img src={char.char.avatar} alt={char.name} className="w-full h-full object-cover" />
                  ) : (
                    <User className="w-7 h-7 text-primary" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold truncate">{char.name}</h3>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                      档案
                    </span>
                  </div>
                  {char.char.personality && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {char.char.personality}
                    </p>
                  )}
                  {(char.char.profession || char.char.age) && (
                    <div className="flex gap-2 mt-1 text-xs text-muted-foreground">
                      {char.char.profession && <span>{char.char.profession}</span>}
                      {char.char.age && <span>{char.char.age}岁</span>}
                    </div>
                  )}
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/characters/edit/${char.id}`);
                  }}
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>
    </PhoneFrame>
  );
};

export default Characters;
