import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PhoneFrame } from '@/components/PhoneFrame';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { storage } from '@/lib/storage';
import { WorldBook } from '@/types';
import { Plus, Trash2, Globe, BookOpen } from 'lucide-react';
import { toast } from 'sonner';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const WorldBooks = () => {
  const navigate = useNavigate();
  const [books, setBooks] = useState<WorldBook[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [editingBook, setEditingBook] = useState<WorldBook | null>(null);
  const [newBook, setNewBook] = useState({
    name: '',
    rules: '',
    isGlobal: false,
  });

  useEffect(() => {
    setBooks(storage.getWorldBooks());
  }, []);

  const handleCreate = () => {
    if (!newBook.name.trim() || !newBook.rules.trim()) {
      toast.error('请填写名称和规则');
      return;
    }

    const book: WorldBook = {
      id: Date.now().toString(),
      name: newBook.name,
      rules: newBook.rules,
      isGlobal: newBook.isGlobal,
      createdAt: Date.now(),
    };

    storage.addWorldBook(book);
    setBooks(storage.getWorldBooks());
    setNewBook({ name: '', rules: '', isGlobal: false });
    setShowCreate(false);
    toast.success('世界书已创建');
  };

  const handleUpdate = () => {
    if (!editingBook) return;
    
    if (!editingBook.name.trim() || !editingBook.rules.trim()) {
      toast.error('请填写名称和规则');
      return;
    }

    storage.updateWorldBook(editingBook.id, {
      name: editingBook.name,
      rules: editingBook.rules,
      isGlobal: editingBook.isGlobal,
    });
    setBooks(storage.getWorldBooks());
    setEditingBook(null);
    toast.success('世界书已更新');
  };

  const handleDelete = (id: string) => {
    if (confirm('确定删除这个世界书吗？')) {
      storage.deleteWorldBook(id);
      setBooks(storage.getWorldBooks());
      toast.success('已删除');
    }
  };

  const toggleGlobal = (book: WorldBook) => {
    storage.updateWorldBook(book.id, { isGlobal: !book.isGlobal });
    setBooks(storage.getWorldBooks());
    toast.success(book.isGlobal ? '已取消全局生效' : '已设为全局生效');
  };

  return (
    <PhoneFrame title="世界书" showBack>
      <div className="h-full flex flex-col bg-background/30 backdrop-blur-md">
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {books.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <BookOpen className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>还没有世界书</p>
              <p className="text-sm mt-1">创建世界书来定义全局规则</p>
            </div>
          ) : (
            books.map((book) => (
              <Card key={book.id} className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <h3 className="font-medium">{book.name}</h3>
                    {book.isGlobal && (
                      <Globe className="w-4 h-4 text-primary" />
                    )}
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setEditingBook(book)}
                    >
                      编辑
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(book.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground mb-3 line-clamp-3 whitespace-pre-wrap">
                  {book.rules}
                </p>
                <div className="flex items-center gap-2">
                  <Switch
                    id={`global-${book.id}`}
                    checked={book.isGlobal}
                    onCheckedChange={() => toggleGlobal(book)}
                  />
                  <Label htmlFor={`global-${book.id}`} className="text-sm">
                    全局生效
                  </Label>
                </div>
              </Card>
            ))
          )}
        </div>

        <div className="p-4 border-t">
          <Dialog open={showCreate} onOpenChange={setShowCreate}>
            <DialogTrigger asChild>
              <Button className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                创建世界书
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-[90vw] sm:max-w-md">
              <DialogHeader>
                <DialogTitle>创建世界书</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="book-name">名称</Label>
                  <Input
                    id="book-name"
                    placeholder="世界书名称"
                    value={newBook.name}
                    onChange={(e) => setNewBook({ ...newBook, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="book-rules">规则</Label>
                  <Textarea
                    id="book-rules"
                    placeholder="输入世界书规则..."
                    value={newBook.rules}
                    onChange={(e) => setNewBook({ ...newBook, rules: e.target.value })}
                    rows={8}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="book-global"
                    checked={newBook.isGlobal}
                    onCheckedChange={(checked) => setNewBook({ ...newBook, isGlobal: checked })}
                  />
                  <Label htmlFor="book-global">全局生效</Label>
                </div>
                <Button onClick={handleCreate} className="w-full">
                  创建
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* 编辑对话框 */}
        <Dialog open={!!editingBook} onOpenChange={(open) => !open && setEditingBook(null)}>
          <DialogContent className="max-w-[90vw] sm:max-w-md">
            <DialogHeader>
              <DialogTitle>编辑世界书</DialogTitle>
            </DialogHeader>
            {editingBook && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="edit-name">名称</Label>
                  <Input
                    id="edit-name"
                    value={editingBook.name}
                    onChange={(e) => setEditingBook({ ...editingBook, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="edit-rules">规则</Label>
                  <Textarea
                    id="edit-rules"
                    value={editingBook.rules}
                    onChange={(e) => setEditingBook({ ...editingBook, rules: e.target.value })}
                    rows={8}
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    id="edit-global"
                    checked={editingBook.isGlobal}
                    onCheckedChange={(checked) => setEditingBook({ ...editingBook, isGlobal: checked })}
                  />
                  <Label htmlFor="edit-global">全局生效</Label>
                </div>
                <Button onClick={handleUpdate} className="w-full">
                  保存
                </Button>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </PhoneFrame>
  );
};

export default WorldBooks;
