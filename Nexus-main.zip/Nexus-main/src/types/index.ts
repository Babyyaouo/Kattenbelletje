export interface ApiSettings {
  apiKey: string;
  baseUrl: string;
  model: string;
  temperature?: number;
  contextRounds?: number;
  mode?: 'online' | 'offline';
}

export interface RoleInfo {
  name: string;
  avatar?: string;
  basicInfo: string;
  profession?: string;
  age?: string;
  personality?: string;
}

export interface Character {
  id: string;
  name: string;
  char: RoleInfo;
  user: RoleInfo;
  type: 'profile';
}

export interface ChatSession {
  id: string;
  characterId: string;
  messages: Message[];
  wallpaper?: string;
  createdAt: number;
  apiSettings?: {
    baseUrl: string;
    apiKey: string;
    model: string;
    temperature?: number;
    contextRounds?: number;
    mode?: 'online' | 'offline';
  };
  displaySettings?: {
    showUserAvatar: boolean;
    showCharAvatar: boolean;
  };
  selectedWorldBooks?: string[];
  coreMemory?: string; // 核心记忆
  coreMemoryTriggerRounds?: number; // 触发核心记忆提取的轮数
}

export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'char';
  timestamp: number;
  type?: 'text' | 'image' | 'transfer';
  imageUrl?: string;
  transferAmount?: number;
}

export interface AppIcon {
  id: string;
  name: string;
  icon: string;
  route: string;
  color: string;
}

export interface WorldBook {
  id: string;
  name: string;
  rules: string;
  isGlobal: boolean;
  createdAt: number;
}

export interface MemoryFragment {
  id: string;
  characterId: string;
  type: 'note' | 'photo' | 'recording' | 'journal' | 'letter';
  emoji: string; // 🌑/🌕/🌓
  location: string;
  timeInfo: string;
  physicalState: string;
  content: string;
  letterType?: 'to-user' | 'to-npc' | 'from-other'; // 信件子类型
  recipientOrSender?: string; // 收件人或发件人
  annotation?: string; // 批注（仅收到的信）
  createdAt: number;
}
