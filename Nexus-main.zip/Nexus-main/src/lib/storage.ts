import { ApiSettings, Character, ChatSession, WorldBook, MemoryFragment } from '@/types';

const STORAGE_KEYS = {
  API_SETTINGS: 'api_settings',
  CHARACTERS: 'characters',
  CHAT_SESSIONS: 'chat_sessions',
  WORLD_BOOKS: 'world_books',
  MEMORY_FRAGMENTS: 'memory_fragments',
};

export const storage = {
  // API Settings
  getApiSettings: (): ApiSettings | null => {
    const data = localStorage.getItem(STORAGE_KEYS.API_SETTINGS);
    return data ? JSON.parse(data) : null;
  },
  
  setApiSettings: (settings: ApiSettings) => {
    localStorage.setItem(STORAGE_KEYS.API_SETTINGS, JSON.stringify(settings));
  },

  // Characters
  getCharacters: (): Character[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHARACTERS);
    return data ? JSON.parse(data) : [];
  },
  
  setCharacters: (characters: Character[]) => {
    try {
      localStorage.setItem(STORAGE_KEYS.CHARACTERS, JSON.stringify(characters));
    } catch (error) {
      if (error instanceof Error && error.name === 'QuotaExceededError') {
        console.error('Storage quota exceeded. Please delete some data.');
        throw new Error('存储空间已满，请删除一些数据后重试');
      }
      throw error;
    }
  },

  addCharacter: (character: Character) => {
    const characters = storage.getCharacters();
    characters.push(character);
    storage.setCharacters(characters);
  },
  
  updateCharacter: (id: string, updates: Partial<Character>) => {
    const characters = storage.getCharacters();
    const index = characters.findIndex(c => c.id === id);
    if (index !== -1) {
      characters[index] = { ...characters[index], ...updates };
      storage.setCharacters(characters);
    }
  },
  
  deleteCharacter: (id: string) => {
    const characters = storage.getCharacters().filter(c => c.id !== id);
    storage.setCharacters(characters);
  },

  // Chat Sessions
  getChatSessions: (): ChatSession[] => {
    const data = localStorage.getItem(STORAGE_KEYS.CHAT_SESSIONS);
    return data ? JSON.parse(data) : [];
  },
  
  setChatSessions: (sessions: ChatSession[]) => {
    localStorage.setItem(STORAGE_KEYS.CHAT_SESSIONS, JSON.stringify(sessions));
  },
  
  addChatSession: (session: ChatSession) => {
    const sessions = storage.getChatSessions();
    sessions.push(session);
    storage.setChatSessions(sessions);
  },
  
  updateChatSession: (id: string, updates: Partial<ChatSession>) => {
    const sessions = storage.getChatSessions();
    const index = sessions.findIndex(s => s.id === id);
    if (index !== -1) {
      sessions[index] = { ...sessions[index], ...updates };
      storage.setChatSessions(sessions);
    }
  },
  
  deleteChatSession: (id: string) => {
    const sessions = storage.getChatSessions().filter(s => s.id !== id);
    storage.setChatSessions(sessions);
  },

  // World Books
  getWorldBooks: (): WorldBook[] => {
    const data = localStorage.getItem(STORAGE_KEYS.WORLD_BOOKS);
    return data ? JSON.parse(data) : [];
  },
  
  setWorldBooks: (books: WorldBook[]) => {
    localStorage.setItem(STORAGE_KEYS.WORLD_BOOKS, JSON.stringify(books));
  },
  
  addWorldBook: (book: WorldBook) => {
    const books = storage.getWorldBooks();
    books.push(book);
    storage.setWorldBooks(books);
  },
  
  updateWorldBook: (id: string, updates: Partial<WorldBook>) => {
    const books = storage.getWorldBooks();
    const index = books.findIndex(b => b.id === id);
    if (index !== -1) {
      books[index] = { ...books[index], ...updates };
      storage.setWorldBooks(books);
    }
  },
  
  deleteWorldBook: (id: string) => {
    const books = storage.getWorldBooks().filter(b => b.id !== id);
    storage.setWorldBooks(books);
  },

  // Memory Fragments
  getMemoryFragments: (): MemoryFragment[] => {
    const data = localStorage.getItem(STORAGE_KEYS.MEMORY_FRAGMENTS);
    return data ? JSON.parse(data) : [];
  },
  
  setMemoryFragments: (fragments: MemoryFragment[]) => {
    localStorage.setItem(STORAGE_KEYS.MEMORY_FRAGMENTS, JSON.stringify(fragments));
  },
  
  addMemoryFragment: (fragment: MemoryFragment) => {
    const fragments = storage.getMemoryFragments();
    fragments.push(fragment);
    storage.setMemoryFragments(fragments);
  },
  
  deleteMemoryFragment: (id: string) => {
    const fragments = storage.getMemoryFragments().filter(f => f.id !== id);
    storage.setMemoryFragments(fragments);
  },
};
